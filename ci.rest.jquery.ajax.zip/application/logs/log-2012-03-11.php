<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-03-11 16:18:29 --> Config Class Initialized
DEBUG - 2012-03-11 16:18:29 --> Hooks Class Initialized
DEBUG - 2012-03-11 16:18:29 --> Utf8 Class Initialized
DEBUG - 2012-03-11 16:18:29 --> UTF-8 Support Enabled
DEBUG - 2012-03-11 16:18:29 --> URI Class Initialized
DEBUG - 2012-03-11 16:18:29 --> Router Class Initialized
DEBUG - 2012-03-11 16:18:29 --> No URI present. Default controller set.
DEBUG - 2012-03-11 16:18:30 --> Output Class Initialized
DEBUG - 2012-03-11 16:18:30 --> Security Class Initialized
DEBUG - 2012-03-11 16:18:30 --> Input Class Initialized
DEBUG - 2012-03-11 16:18:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-11 16:18:30 --> Language Class Initialized
DEBUG - 2012-03-11 16:18:30 --> Loader Class Initialized
DEBUG - 2012-03-11 16:18:30 --> Helper loaded: url_helper
DEBUG - 2012-03-11 16:18:30 --> Unit Testing Class Initialized
DEBUG - 2012-03-11 16:18:30 --> Session Class Initialized
DEBUG - 2012-03-11 16:18:30 --> Helper loaded: string_helper
DEBUG - 2012-03-11 16:18:30 --> A session cookie was not found.
DEBUG - 2012-03-11 16:18:30 --> Session routines successfully run
DEBUG - 2012-03-11 16:18:30 --> Controller Class Initialized
DEBUG - 2012-03-11 16:18:30 --> File loaded: application/views/header.php
DEBUG - 2012-03-11 16:18:30 --> File loaded: application/views/nav.php
DEBUG - 2012-03-11 16:18:30 --> File loaded: application/views/login.php
DEBUG - 2012-03-11 16:18:30 --> File loaded: application/views/home.php
DEBUG - 2012-03-11 16:18:30 --> File loaded: application/views/footer.php
DEBUG - 2012-03-11 16:18:30 --> File loaded: application/views/layout.php
DEBUG - 2012-03-11 16:18:30 --> Final output sent to browser
DEBUG - 2012-03-11 16:18:30 --> Total execution time: 0.8285
