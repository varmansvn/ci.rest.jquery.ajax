<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-03-27 16:39:06 --> Config Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Hooks Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Utf8 Class Initialized
DEBUG - 2012-03-27 16:39:06 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 16:39:06 --> URI Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Router Class Initialized
DEBUG - 2012-03-27 16:39:06 --> No URI present. Default controller set.
DEBUG - 2012-03-27 16:39:06 --> Output Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Security Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Input Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 16:39:06 --> Language Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Loader Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Helper loaded: url_helper
DEBUG - 2012-03-27 16:39:06 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Session Class Initialized
DEBUG - 2012-03-27 16:39:06 --> Helper loaded: string_helper
DEBUG - 2012-03-27 16:39:06 --> A session cookie was not found.
DEBUG - 2012-03-27 16:39:06 --> Session routines successfully run
DEBUG - 2012-03-27 16:39:06 --> Controller Class Initialized
DEBUG - 2012-03-27 16:39:06 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 16:39:06 --> File loaded: application/views/nav.php
DEBUG - 2012-03-27 16:39:06 --> File loaded: application/views/login.php
DEBUG - 2012-03-27 16:39:06 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 16:39:06 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 16:39:06 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 16:39:06 --> Final output sent to browser
DEBUG - 2012-03-27 16:39:06 --> Total execution time: 0.1268
DEBUG - 2012-03-27 16:39:09 --> Config Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Hooks Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Utf8 Class Initialized
DEBUG - 2012-03-27 16:39:09 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 16:39:09 --> URI Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Router Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Output Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Security Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Input Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 16:39:09 --> Language Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Loader Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Helper loaded: url_helper
DEBUG - 2012-03-27 16:39:09 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Session Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Helper loaded: string_helper
DEBUG - 2012-03-27 16:39:09 --> Session routines successfully run
DEBUG - 2012-03-27 16:39:09 --> Controller Class Initialized
DEBUG - 2012-03-27 16:39:09 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 16:39:09 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 16:39:16 --> Config Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Hooks Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Utf8 Class Initialized
DEBUG - 2012-03-27 16:39:16 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 16:39:16 --> URI Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Router Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Output Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Security Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Input Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 16:39:16 --> Language Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Loader Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Helper loaded: url_helper
DEBUG - 2012-03-27 16:39:16 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Session Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Helper loaded: string_helper
DEBUG - 2012-03-27 16:39:16 --> Session routines successfully run
DEBUG - 2012-03-27 16:39:16 --> Controller Class Initialized
DEBUG - 2012-03-27 16:39:16 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 16:39:16 --> Helper loaded: inflector_helper
INFO  - 2012-03-27 16:39:16 --> Users::login_post::20function entry
ERROR - 2012-03-27 16:39:16 --> Severity: Warning  --> require(application/models\Entities\User.php) [<a href='function.require'>function.require</a>]: failed to open stream: No such file or directory C:\Users\varman\devwork\projects\webapp\ci.jquery.ajax\application\libraries\Doctrine\Common\ClassLoader.php 148
DEBUG - 2012-03-27 17:30:30 --> Config Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:30:30 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:30:30 --> URI Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Router Class Initialized
DEBUG - 2012-03-27 17:30:30 --> No URI present. Default controller set.
DEBUG - 2012-03-27 17:30:30 --> Output Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Security Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Input Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:30:30 --> Language Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Loader Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:30:30 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Session Class Initialized
DEBUG - 2012-03-27 17:30:30 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:30:30 --> Session routines successfully run
DEBUG - 2012-03-27 17:30:30 --> Controller Class Initialized
DEBUG - 2012-03-27 17:30:30 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:30:30 --> File loaded: application/views/nav.php
DEBUG - 2012-03-27 17:30:30 --> File loaded: application/views/product_list.php
DEBUG - 2012-03-27 17:30:30 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 17:30:30 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:30:30 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:30:30 --> Final output sent to browser
DEBUG - 2012-03-27 17:30:30 --> Total execution time: 0.1212
DEBUG - 2012-03-27 17:30:31 --> Config Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:30:31 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:30:31 --> URI Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Router Class Initialized
DEBUG - 2012-03-27 17:30:31 --> No URI present. Default controller set.
DEBUG - 2012-03-27 17:30:31 --> Output Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Security Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Input Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:30:31 --> Language Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Loader Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:30:31 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Session Class Initialized
DEBUG - 2012-03-27 17:30:31 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:30:31 --> Session routines successfully run
DEBUG - 2012-03-27 17:30:31 --> Controller Class Initialized
DEBUG - 2012-03-27 17:30:31 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:30:31 --> File loaded: application/views/nav.php
DEBUG - 2012-03-27 17:30:31 --> File loaded: application/views/product_list.php
DEBUG - 2012-03-27 17:30:31 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 17:30:31 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:30:31 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:30:31 --> Final output sent to browser
DEBUG - 2012-03-27 17:30:31 --> Total execution time: 0.1096
DEBUG - 2012-03-27 17:30:32 --> Config Class Initialized
DEBUG - 2012-03-27 17:30:32 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:30:32 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:30:32 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:30:32 --> URI Class Initialized
DEBUG - 2012-03-27 17:30:32 --> Router Class Initialized
DEBUG - 2012-03-27 17:30:32 --> Output Class Initialized
DEBUG - 2012-03-27 17:30:32 --> Security Class Initialized
DEBUG - 2012-03-27 17:30:32 --> Input Class Initialized
DEBUG - 2012-03-27 17:30:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:30:32 --> Language Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Config Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:33:26 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:33:26 --> URI Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Router Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Output Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Security Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Input Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:33:26 --> Language Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Loader Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:33:26 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Session Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:33:26 --> Session routines successfully run
DEBUG - 2012-03-27 17:33:26 --> Controller Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:33:26 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:33:26 --> Config Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:33:26 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:33:26 --> URI Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Router Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Output Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Security Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Input Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:33:26 --> Language Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Loader Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:33:26 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Session Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:33:26 --> Session routines successfully run
DEBUG - 2012-03-27 17:33:26 --> Controller Class Initialized
DEBUG - 2012-03-27 17:33:26 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:33:26 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:33:38 --> Config Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:33:38 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:33:38 --> URI Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Router Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Output Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Security Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Input Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:33:38 --> Language Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Loader Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:33:38 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Session Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:33:38 --> Session routines successfully run
DEBUG - 2012-03-27 17:33:38 --> Controller Class Initialized
DEBUG - 2012-03-27 17:33:38 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:33:38 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:34:44 --> Config Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:34:44 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:34:44 --> URI Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Router Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Output Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Security Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Input Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:34:44 --> Language Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Loader Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:34:44 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Session Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:34:44 --> Session routines successfully run
DEBUG - 2012-03-27 17:34:44 --> Controller Class Initialized
DEBUG - 2012-03-27 17:34:44 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:34:44 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:34:49 --> Config Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:34:49 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:34:49 --> URI Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Router Class Initialized
DEBUG - 2012-03-27 17:34:49 --> No URI present. Default controller set.
DEBUG - 2012-03-27 17:34:49 --> Output Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Security Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Input Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:34:49 --> Language Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Loader Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:34:49 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Session Class Initialized
DEBUG - 2012-03-27 17:34:49 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:34:49 --> Session routines successfully run
DEBUG - 2012-03-27 17:34:49 --> Controller Class Initialized
DEBUG - 2012-03-27 17:34:49 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:34:49 --> File loaded: application/views/nav.php
DEBUG - 2012-03-27 17:34:49 --> File loaded: application/views/product_list.php
DEBUG - 2012-03-27 17:34:49 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 17:34:49 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:34:49 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:34:49 --> Final output sent to browser
DEBUG - 2012-03-27 17:34:49 --> Total execution time: 0.1323
DEBUG - 2012-03-27 17:34:51 --> Config Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:34:51 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:34:51 --> URI Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Router Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Output Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Security Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Input Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:34:51 --> Language Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Loader Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:34:51 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Session Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:34:51 --> Session routines successfully run
DEBUG - 2012-03-27 17:34:51 --> Controller Class Initialized
DEBUG - 2012-03-27 17:34:51 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:34:51 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:34:53 --> Config Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:34:53 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:34:53 --> URI Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Router Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Output Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Security Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Input Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:34:53 --> Language Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Loader Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:34:53 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Session Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:34:53 --> Session routines successfully run
DEBUG - 2012-03-27 17:34:53 --> Controller Class Initialized
DEBUG - 2012-03-27 17:34:53 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:34:53 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:34:55 --> Config Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:34:55 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:34:55 --> URI Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Router Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Output Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Security Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Input Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:34:55 --> Language Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Loader Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:34:55 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Session Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:34:55 --> Session routines successfully run
DEBUG - 2012-03-27 17:34:55 --> Controller Class Initialized
DEBUG - 2012-03-27 17:34:55 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:34:55 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:36:10 --> Config Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:36:10 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:36:10 --> URI Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Router Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Output Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Security Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Input Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:36:10 --> Language Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Loader Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:36:10 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Session Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:36:10 --> Session routines successfully run
DEBUG - 2012-03-27 17:36:10 --> Controller Class Initialized
DEBUG - 2012-03-27 17:36:10 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:36:10 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:36:14 --> Config Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:36:15 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:36:15 --> URI Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Router Class Initialized
DEBUG - 2012-03-27 17:36:15 --> No URI present. Default controller set.
DEBUG - 2012-03-27 17:36:15 --> Output Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Security Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Input Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:36:15 --> Language Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Loader Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:36:15 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Session Class Initialized
DEBUG - 2012-03-27 17:36:15 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:36:15 --> Session routines successfully run
DEBUG - 2012-03-27 17:36:15 --> Controller Class Initialized
DEBUG - 2012-03-27 17:36:15 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:36:15 --> File loaded: application/views/nav.php
DEBUG - 2012-03-27 17:36:15 --> File loaded: application/views/product_list.php
DEBUG - 2012-03-27 17:36:15 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 17:36:15 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:36:15 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:36:15 --> Final output sent to browser
DEBUG - 2012-03-27 17:36:15 --> Total execution time: 0.1481
DEBUG - 2012-03-27 17:36:33 --> Config Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:36:33 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:36:33 --> URI Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Router Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Output Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Security Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Input Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:36:33 --> Language Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Loader Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:36:33 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Session Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:36:33 --> Session routines successfully run
DEBUG - 2012-03-27 17:36:33 --> Controller Class Initialized
DEBUG - 2012-03-27 17:36:33 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:36:33 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:37:12 --> Config Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:37:12 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:37:12 --> URI Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Router Class Initialized
DEBUG - 2012-03-27 17:37:12 --> No URI present. Default controller set.
DEBUG - 2012-03-27 17:37:12 --> Output Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Security Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Input Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:37:12 --> Language Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Loader Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:37:12 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Session Class Initialized
DEBUG - 2012-03-27 17:37:12 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:37:12 --> Session routines successfully run
DEBUG - 2012-03-27 17:37:12 --> Controller Class Initialized
DEBUG - 2012-03-27 17:37:12 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:37:12 --> File loaded: application/views/nav.php
DEBUG - 2012-03-27 17:37:12 --> File loaded: application/views/product_list.php
DEBUG - 2012-03-27 17:37:12 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 17:37:12 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:37:12 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:37:12 --> Final output sent to browser
DEBUG - 2012-03-27 17:37:12 --> Total execution time: 0.1129
DEBUG - 2012-03-27 17:37:21 --> Config Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:37:21 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:37:21 --> URI Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Router Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Output Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Security Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Input Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:37:21 --> Language Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Loader Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:37:21 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Session Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:37:21 --> Session routines successfully run
DEBUG - 2012-03-27 17:37:21 --> Controller Class Initialized
DEBUG - 2012-03-27 17:37:21 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 17:37:21 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 17:53:47 --> Config Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:53:47 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:53:47 --> URI Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Router Class Initialized
DEBUG - 2012-03-27 17:53:47 --> No URI present. Default controller set.
DEBUG - 2012-03-27 17:53:47 --> Output Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Security Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Input Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:53:47 --> Language Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Loader Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:53:47 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Session Class Initialized
DEBUG - 2012-03-27 17:53:47 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:53:47 --> Session routines successfully run
DEBUG - 2012-03-27 17:53:47 --> Controller Class Initialized
DEBUG - 2012-03-27 17:53:47 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:53:47 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 17:53:47 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:53:47 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:53:47 --> Final output sent to browser
DEBUG - 2012-03-27 17:53:47 --> Total execution time: 0.1181
DEBUG - 2012-03-27 17:53:49 --> Config Class Initialized
DEBUG - 2012-03-27 17:53:49 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:53:50 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:53:50 --> URI Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Router Class Initialized
DEBUG - 2012-03-27 17:53:50 --> No URI present. Default controller set.
DEBUG - 2012-03-27 17:53:50 --> Output Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Security Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Input Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:53:50 --> Language Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Loader Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:53:50 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Session Class Initialized
DEBUG - 2012-03-27 17:53:50 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:53:50 --> Session routines successfully run
DEBUG - 2012-03-27 17:53:50 --> Controller Class Initialized
DEBUG - 2012-03-27 17:53:50 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:53:50 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 17:53:50 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:53:50 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:53:50 --> Final output sent to browser
DEBUG - 2012-03-27 17:53:50 --> Total execution time: 0.1082
DEBUG - 2012-03-27 17:54:59 --> Config Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:54:59 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:54:59 --> URI Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Router Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Output Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Security Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Input Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:54:59 --> Language Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Loader Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:54:59 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Session Class Initialized
DEBUG - 2012-03-27 17:54:59 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:54:59 --> Session routines successfully run
DEBUG - 2012-03-27 17:54:59 --> Controller Class Initialized
DEBUG - 2012-03-27 17:54:59 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:54:59 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 17:54:59 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:54:59 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:54:59 --> Final output sent to browser
DEBUG - 2012-03-27 17:54:59 --> Total execution time: 0.1226
DEBUG - 2012-03-27 17:55:01 --> Config Class Initialized
DEBUG - 2012-03-27 17:55:01 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:55:01 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:55:01 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:55:01 --> URI Class Initialized
DEBUG - 2012-03-27 17:55:01 --> Router Class Initialized
DEBUG - 2012-03-27 17:55:01 --> Output Class Initialized
DEBUG - 2012-03-27 17:55:01 --> Security Class Initialized
DEBUG - 2012-03-27 17:55:01 --> Input Class Initialized
DEBUG - 2012-03-27 17:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:55:01 --> Language Class Initialized
DEBUG - 2012-03-27 17:55:03 --> Config Class Initialized
DEBUG - 2012-03-27 17:55:03 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:55:03 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:55:03 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:55:03 --> URI Class Initialized
DEBUG - 2012-03-27 17:55:03 --> Router Class Initialized
ERROR - 2012-03-27 17:55:03 --> 404 Page Not Found --> api/usercomp
DEBUG - 2012-03-27 17:55:55 --> Config Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:55:55 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:55:55 --> URI Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Router Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Output Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Security Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Input Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:55:55 --> Language Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Loader Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:55:55 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Session Class Initialized
DEBUG - 2012-03-27 17:55:55 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:55:55 --> Session routines successfully run
DEBUG - 2012-03-27 17:55:55 --> Controller Class Initialized
DEBUG - 2012-03-27 17:55:55 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:55:55 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 17:55:55 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:55:55 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:55:55 --> Final output sent to browser
DEBUG - 2012-03-27 17:55:55 --> Total execution time: 0.1061
DEBUG - 2012-03-27 17:55:56 --> Config Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:55:56 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:55:56 --> URI Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Router Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Output Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Security Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Input Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:55:56 --> Language Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Loader Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Helper loaded: url_helper
DEBUG - 2012-03-27 17:55:56 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Session Class Initialized
DEBUG - 2012-03-27 17:55:56 --> Helper loaded: string_helper
DEBUG - 2012-03-27 17:55:56 --> Session routines successfully run
DEBUG - 2012-03-27 17:55:56 --> Controller Class Initialized
DEBUG - 2012-03-27 17:55:56 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 17:55:56 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 17:55:56 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 17:55:56 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 17:55:56 --> Final output sent to browser
DEBUG - 2012-03-27 17:55:56 --> Total execution time: 0.0979
DEBUG - 2012-03-27 17:56:02 --> Config Class Initialized
DEBUG - 2012-03-27 17:56:02 --> Hooks Class Initialized
DEBUG - 2012-03-27 17:56:02 --> Utf8 Class Initialized
DEBUG - 2012-03-27 17:56:02 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 17:56:02 --> URI Class Initialized
DEBUG - 2012-03-27 17:56:02 --> Router Class Initialized
DEBUG - 2012-03-27 17:56:02 --> Output Class Initialized
DEBUG - 2012-03-27 17:56:02 --> Security Class Initialized
DEBUG - 2012-03-27 17:56:02 --> Input Class Initialized
DEBUG - 2012-03-27 17:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 17:56:02 --> Language Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Config Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:08:22 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:08:22 --> URI Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Router Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Output Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Security Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Input Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:08:22 --> Language Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Loader Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:08:22 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Session Class Initialized
DEBUG - 2012-03-27 18:08:22 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:08:22 --> Session routines successfully run
DEBUG - 2012-03-27 18:08:22 --> Controller Class Initialized
DEBUG - 2012-03-27 18:08:23 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:08:23 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:08:23 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:08:23 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:08:23 --> Final output sent to browser
DEBUG - 2012-03-27 18:08:23 --> Total execution time: 0.1162
DEBUG - 2012-03-27 18:08:24 --> Config Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:08:24 --> URI Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Router Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Output Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Security Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Input Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:08:24 --> Language Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Loader Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:08:24 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Session Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:08:24 --> Session routines successfully run
DEBUG - 2012-03-27 18:08:24 --> Controller Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:08:24 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:08:24 --> Config Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:08:24 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:08:24 --> URI Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Router Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Output Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Security Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Input Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:08:24 --> Language Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Loader Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:08:24 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Session Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:08:24 --> Session routines successfully run
DEBUG - 2012-03-27 18:08:24 --> Controller Class Initialized
DEBUG - 2012-03-27 18:08:24 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:08:24 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:08:30 --> Config Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:08:30 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:08:30 --> URI Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Router Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Output Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Security Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Input Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:08:30 --> Language Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Loader Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:08:30 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Session Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:08:30 --> Session routines successfully run
DEBUG - 2012-03-27 18:08:30 --> Controller Class Initialized
DEBUG - 2012-03-27 18:08:30 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:08:30 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:08:58 --> Config Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:08:58 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:08:58 --> URI Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Router Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Output Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Security Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Input Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:08:58 --> Language Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Loader Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:08:58 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Session Class Initialized
DEBUG - 2012-03-27 18:08:58 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:08:58 --> Session routines successfully run
DEBUG - 2012-03-27 18:08:58 --> Controller Class Initialized
DEBUG - 2012-03-27 18:08:58 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:08:58 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:08:58 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:08:58 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:08:58 --> Final output sent to browser
DEBUG - 2012-03-27 18:08:58 --> Total execution time: 0.1062
DEBUG - 2012-03-27 18:09:02 --> Config Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:09:02 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:09:02 --> URI Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Router Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Output Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Security Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Input Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:09:02 --> Language Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Loader Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:09:02 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Session Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:09:02 --> Session routines successfully run
DEBUG - 2012-03-27 18:09:02 --> Controller Class Initialized
DEBUG - 2012-03-27 18:09:02 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:09:02 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:09:50 --> Config Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:09:50 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:09:50 --> URI Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Router Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Output Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Security Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Input Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:09:50 --> Language Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Loader Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:09:50 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Session Class Initialized
DEBUG - 2012-03-27 18:09:50 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:09:50 --> Session routines successfully run
DEBUG - 2012-03-27 18:09:50 --> Controller Class Initialized
DEBUG - 2012-03-27 18:09:50 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:09:50 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:09:50 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:09:50 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:09:50 --> Final output sent to browser
DEBUG - 2012-03-27 18:09:50 --> Total execution time: 0.1009
DEBUG - 2012-03-27 18:09:52 --> Config Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:09:52 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:09:52 --> URI Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Router Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Output Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Security Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Input Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:09:52 --> Language Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Loader Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:09:52 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Session Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:09:52 --> Session routines successfully run
DEBUG - 2012-03-27 18:09:52 --> Controller Class Initialized
DEBUG - 2012-03-27 18:09:52 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:09:52 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:11:03 --> Config Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:11:03 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:11:03 --> URI Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Router Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Output Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Security Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Input Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:11:03 --> Language Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Loader Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:11:03 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Session Class Initialized
DEBUG - 2012-03-27 18:11:03 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:11:03 --> Session routines successfully run
DEBUG - 2012-03-27 18:11:03 --> Controller Class Initialized
DEBUG - 2012-03-27 18:11:03 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:11:03 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:11:03 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:11:03 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:11:03 --> Final output sent to browser
DEBUG - 2012-03-27 18:11:03 --> Total execution time: 0.1111
DEBUG - 2012-03-27 18:11:04 --> Config Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:11:04 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:11:04 --> URI Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Router Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Output Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Security Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Input Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:11:04 --> Language Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Loader Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:11:04 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Session Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:11:04 --> Session routines successfully run
DEBUG - 2012-03-27 18:11:04 --> Controller Class Initialized
DEBUG - 2012-03-27 18:11:04 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:11:04 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:11:38 --> Config Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:11:38 --> URI Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Router Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Output Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Security Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Input Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:11:38 --> Language Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Loader Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:11:38 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Session Class Initialized
DEBUG - 2012-03-27 18:11:38 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:11:38 --> Session routines successfully run
DEBUG - 2012-03-27 18:11:38 --> Controller Class Initialized
DEBUG - 2012-03-27 18:11:38 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:11:38 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:11:38 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:11:38 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:11:38 --> Final output sent to browser
DEBUG - 2012-03-27 18:11:38 --> Total execution time: 0.1735
DEBUG - 2012-03-27 18:11:39 --> Config Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:11:39 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:11:39 --> URI Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Router Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Output Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Security Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Input Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:11:39 --> Language Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Loader Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:11:39 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Session Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:11:39 --> Session routines successfully run
DEBUG - 2012-03-27 18:11:39 --> Controller Class Initialized
DEBUG - 2012-03-27 18:11:39 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:11:39 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:12:09 --> Config Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:12:09 --> URI Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Router Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Output Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Security Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Input Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:12:09 --> Language Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Loader Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:12:09 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Session Class Initialized
DEBUG - 2012-03-27 18:12:09 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:12:09 --> Session routines successfully run
DEBUG - 2012-03-27 18:12:09 --> Controller Class Initialized
DEBUG - 2012-03-27 18:12:09 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:12:09 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:12:09 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:12:09 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:12:09 --> Final output sent to browser
DEBUG - 2012-03-27 18:12:09 --> Total execution time: 0.1703
DEBUG - 2012-03-27 18:12:10 --> Config Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:12:10 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:12:10 --> URI Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Router Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Output Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Security Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Input Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:12:10 --> Language Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Loader Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:12:10 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Session Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:12:10 --> Session routines successfully run
DEBUG - 2012-03-27 18:12:10 --> Controller Class Initialized
DEBUG - 2012-03-27 18:12:10 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:12:10 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:12:48 --> Config Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:12:48 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:12:48 --> URI Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Router Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Output Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Security Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Input Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:12:48 --> Language Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Loader Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:12:48 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Session Class Initialized
DEBUG - 2012-03-27 18:12:48 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:12:48 --> Session routines successfully run
DEBUG - 2012-03-27 18:12:48 --> Controller Class Initialized
DEBUG - 2012-03-27 18:12:48 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:12:48 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:12:48 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:12:48 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:12:48 --> Final output sent to browser
DEBUG - 2012-03-27 18:12:48 --> Total execution time: 0.1208
DEBUG - 2012-03-27 18:12:49 --> Config Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:12:49 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:12:49 --> URI Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Router Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Output Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Security Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Input Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:12:49 --> Language Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Loader Class Initialized
DEBUG - 2012-03-27 18:12:49 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:12:50 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:12:50 --> Session Class Initialized
DEBUG - 2012-03-27 18:12:50 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:12:50 --> Session routines successfully run
DEBUG - 2012-03-27 18:12:50 --> Controller Class Initialized
DEBUG - 2012-03-27 18:12:50 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:12:50 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:12:52 --> Config Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:12:52 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:12:52 --> URI Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Router Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Output Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Security Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Input Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:12:52 --> Language Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Loader Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:12:52 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Session Class Initialized
DEBUG - 2012-03-27 18:12:52 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:12:52 --> Session routines successfully run
DEBUG - 2012-03-27 18:12:52 --> Controller Class Initialized
DEBUG - 2012-03-27 18:12:52 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:12:52 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:12:52 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:12:52 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:12:52 --> Final output sent to browser
DEBUG - 2012-03-27 18:12:52 --> Total execution time: 0.1529
DEBUG - 2012-03-27 18:12:55 --> Config Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:12:55 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:12:55 --> URI Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Router Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Output Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Security Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Input Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:12:55 --> Language Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Loader Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:12:55 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Session Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:12:55 --> Session routines successfully run
DEBUG - 2012-03-27 18:12:55 --> Controller Class Initialized
DEBUG - 2012-03-27 18:12:55 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:12:55 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:14:20 --> Config Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:14:20 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:14:20 --> URI Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Router Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Output Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Security Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Input Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:14:20 --> Language Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Loader Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:14:20 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Session Class Initialized
DEBUG - 2012-03-27 18:14:20 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:14:20 --> Session routines successfully run
DEBUG - 2012-03-27 18:14:20 --> Controller Class Initialized
DEBUG - 2012-03-27 18:14:20 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:14:20 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:14:20 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:14:20 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:14:20 --> Final output sent to browser
DEBUG - 2012-03-27 18:14:20 --> Total execution time: 0.1464
DEBUG - 2012-03-27 18:14:21 --> Config Class Initialized
DEBUG - 2012-03-27 18:14:21 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:14:21 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:14:21 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:14:21 --> URI Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Router Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Output Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Security Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Input Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:14:22 --> Language Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Loader Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:14:22 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Session Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:14:22 --> Session routines successfully run
DEBUG - 2012-03-27 18:14:22 --> Controller Class Initialized
DEBUG - 2012-03-27 18:14:22 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:14:22 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:15:19 --> Config Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:15:19 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:15:19 --> URI Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Router Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Output Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Security Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Input Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:15:19 --> Language Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Loader Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:15:19 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Session Class Initialized
DEBUG - 2012-03-27 18:15:19 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:15:19 --> Session routines successfully run
DEBUG - 2012-03-27 18:15:19 --> Controller Class Initialized
DEBUG - 2012-03-27 18:15:19 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:15:19 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:15:19 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:15:19 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:15:19 --> Final output sent to browser
DEBUG - 2012-03-27 18:15:19 --> Total execution time: 0.1289
DEBUG - 2012-03-27 18:15:20 --> Config Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:15:20 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:15:20 --> URI Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Router Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Output Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Security Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Input Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:15:20 --> Language Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Loader Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:15:20 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Session Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:15:20 --> Session routines successfully run
DEBUG - 2012-03-27 18:15:20 --> Controller Class Initialized
DEBUG - 2012-03-27 18:15:20 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:15:20 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:15:20 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:15:20 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:15:20 --> Final output sent to browser
DEBUG - 2012-03-27 18:15:20 --> Total execution time: 0.1162
DEBUG - 2012-03-27 18:15:20 --> Config Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:15:20 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:15:20 --> URI Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Router Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Output Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Security Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Input Class Initialized
DEBUG - 2012-03-27 18:15:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:15:20 --> Language Class Initialized
DEBUG - 2012-03-27 18:15:21 --> Loader Class Initialized
DEBUG - 2012-03-27 18:15:21 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:15:21 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:15:21 --> Session Class Initialized
DEBUG - 2012-03-27 18:15:21 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:15:21 --> Session routines successfully run
DEBUG - 2012-03-27 18:15:21 --> Controller Class Initialized
DEBUG - 2012-03-27 18:15:21 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:15:21 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:15:21 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:15:21 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:15:21 --> Final output sent to browser
DEBUG - 2012-03-27 18:15:21 --> Total execution time: 0.1288
DEBUG - 2012-03-27 18:15:24 --> Config Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:15:24 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:15:24 --> URI Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Router Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Output Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Security Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Input Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:15:24 --> Language Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Loader Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:15:24 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Session Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:15:24 --> Session routines successfully run
DEBUG - 2012-03-27 18:15:24 --> Controller Class Initialized
DEBUG - 2012-03-27 18:15:24 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:15:24 --> Helper loaded: inflector_helper
ERROR - 2012-03-27 18:15:24 --> Severity: Notice  --> Undefined variable: user C:\Users\varman\devwork\projects\webapp\ci.jquery.ajax\application\controllers\api\userapi.php 38
ERROR - 2012-03-27 18:15:24 --> Severity: Notice  --> Undefined variable: user C:\Users\varman\devwork\projects\webapp\ci.jquery.ajax\application\controllers\api\userapi.php 40
DEBUG - 2012-03-27 18:15:43 --> Config Class Initialized
DEBUG - 2012-03-27 18:15:43 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:15:43 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:15:43 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:15:43 --> URI Class Initialized
DEBUG - 2012-03-27 18:15:43 --> Router Class Initialized
DEBUG - 2012-03-27 18:15:44 --> Output Class Initialized
DEBUG - 2012-03-27 18:15:44 --> Security Class Initialized
DEBUG - 2012-03-27 18:15:44 --> Input Class Initialized
DEBUG - 2012-03-27 18:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:15:44 --> Language Class Initialized
DEBUG - 2012-03-27 18:15:44 --> Loader Class Initialized
DEBUG - 2012-03-27 18:15:44 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:15:44 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:15:44 --> Session Class Initialized
DEBUG - 2012-03-27 18:15:44 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:15:44 --> Session routines successfully run
DEBUG - 2012-03-27 18:15:44 --> Controller Class Initialized
DEBUG - 2012-03-27 18:15:44 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:15:44 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:15:44 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:15:44 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:15:44 --> Final output sent to browser
DEBUG - 2012-03-27 18:15:44 --> Total execution time: 0.1230
DEBUG - 2012-03-27 18:15:47 --> Config Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:15:47 --> URI Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Router Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Output Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Security Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Input Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:15:47 --> Language Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Loader Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:15:47 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Session Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:15:47 --> Session routines successfully run
DEBUG - 2012-03-27 18:15:47 --> Controller Class Initialized
DEBUG - 2012-03-27 18:15:47 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:15:47 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:16:45 --> Config Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:16:45 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:16:45 --> URI Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Router Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Output Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Security Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Input Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:16:45 --> Language Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Loader Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:16:45 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Session Class Initialized
DEBUG - 2012-03-27 18:16:45 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:16:45 --> Session routines successfully run
DEBUG - 2012-03-27 18:16:45 --> Controller Class Initialized
DEBUG - 2012-03-27 18:16:45 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:16:45 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:16:45 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:16:45 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:16:45 --> Final output sent to browser
DEBUG - 2012-03-27 18:16:45 --> Total execution time: 0.1314
DEBUG - 2012-03-27 18:16:49 --> Config Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:16:49 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:16:49 --> URI Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Router Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Output Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Security Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Input Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:16:49 --> Language Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Loader Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:16:49 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Session Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:16:49 --> Session routines successfully run
DEBUG - 2012-03-27 18:16:49 --> Controller Class Initialized
DEBUG - 2012-03-27 18:16:49 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:16:49 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:19:54 --> Config Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:19:54 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:19:54 --> URI Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Router Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Output Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Security Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Input Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:19:54 --> Language Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Loader Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:19:54 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Session Class Initialized
DEBUG - 2012-03-27 18:19:54 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:19:54 --> Session routines successfully run
DEBUG - 2012-03-27 18:19:54 --> Controller Class Initialized
DEBUG - 2012-03-27 18:19:54 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:19:54 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:19:54 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:19:54 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:19:54 --> Final output sent to browser
DEBUG - 2012-03-27 18:19:54 --> Total execution time: 0.1362
DEBUG - 2012-03-27 18:19:58 --> Config Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:19:58 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:19:58 --> URI Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Router Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Output Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Security Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Input Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:19:58 --> Language Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Loader Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:19:58 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Session Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:19:58 --> Session routines successfully run
DEBUG - 2012-03-27 18:19:58 --> Controller Class Initialized
DEBUG - 2012-03-27 18:19:58 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:19:58 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:22:09 --> Config Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:22:09 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:22:09 --> URI Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Router Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Output Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Security Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Input Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:22:09 --> Language Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Loader Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:22:09 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Session Class Initialized
DEBUG - 2012-03-27 18:22:09 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:22:10 --> Session routines successfully run
DEBUG - 2012-03-27 18:22:10 --> Controller Class Initialized
DEBUG - 2012-03-27 18:22:10 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:22:10 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:22:10 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:22:10 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:22:10 --> Final output sent to browser
DEBUG - 2012-03-27 18:22:10 --> Total execution time: 0.1724
DEBUG - 2012-03-27 18:22:12 --> Config Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:22:12 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:22:12 --> URI Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Router Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Output Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Security Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Input Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:22:12 --> Language Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Loader Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:22:12 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Session Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:22:12 --> Session routines successfully run
DEBUG - 2012-03-27 18:22:12 --> Controller Class Initialized
DEBUG - 2012-03-27 18:22:12 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:22:12 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:23:06 --> Config Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:23:06 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:23:06 --> URI Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Router Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Output Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Security Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Input Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:23:06 --> Language Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Loader Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:23:06 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Session Class Initialized
DEBUG - 2012-03-27 18:23:06 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:23:06 --> Session routines successfully run
DEBUG - 2012-03-27 18:23:06 --> Controller Class Initialized
DEBUG - 2012-03-27 18:23:06 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:23:06 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:23:06 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:23:06 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:23:06 --> Final output sent to browser
DEBUG - 2012-03-27 18:23:06 --> Total execution time: 0.1382
DEBUG - 2012-03-27 18:23:08 --> Config Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:23:08 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:23:08 --> URI Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Router Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Output Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Security Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Input Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:23:08 --> Language Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Loader Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:23:08 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Session Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:23:08 --> Session routines successfully run
DEBUG - 2012-03-27 18:23:08 --> Controller Class Initialized
DEBUG - 2012-03-27 18:23:08 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:23:08 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:23:36 --> Config Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:23:36 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:23:36 --> URI Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Router Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Output Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Security Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Input Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:23:36 --> Language Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Loader Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:23:36 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Session Class Initialized
DEBUG - 2012-03-27 18:23:36 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:23:36 --> Session routines successfully run
DEBUG - 2012-03-27 18:23:36 --> Controller Class Initialized
DEBUG - 2012-03-27 18:23:36 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:23:36 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:23:36 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:23:36 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:23:36 --> Final output sent to browser
DEBUG - 2012-03-27 18:23:36 --> Total execution time: 0.1368
DEBUG - 2012-03-27 18:23:37 --> Config Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:23:37 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:23:37 --> URI Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Router Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Output Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Security Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Input Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:23:37 --> Language Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Loader Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:23:37 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Session Class Initialized
DEBUG - 2012-03-27 18:23:37 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:23:37 --> Session routines successfully run
DEBUG - 2012-03-27 18:23:37 --> Controller Class Initialized
DEBUG - 2012-03-27 18:23:37 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:23:37 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:23:37 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:23:37 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:23:37 --> Final output sent to browser
DEBUG - 2012-03-27 18:23:37 --> Total execution time: 0.1250
DEBUG - 2012-03-27 18:23:40 --> Config Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:23:40 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:23:40 --> URI Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Router Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Output Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Security Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Input Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:23:40 --> Language Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Loader Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:23:40 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Session Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:23:40 --> Session routines successfully run
DEBUG - 2012-03-27 18:23:40 --> Controller Class Initialized
DEBUG - 2012-03-27 18:23:40 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:23:40 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:25:07 --> Config Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:25:07 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:25:07 --> URI Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Router Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Output Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Security Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Input Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:25:07 --> Language Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Loader Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:25:07 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Session Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:25:07 --> Session routines successfully run
DEBUG - 2012-03-27 18:25:07 --> Controller Class Initialized
DEBUG - 2012-03-27 18:25:07 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:25:07 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:25:11 --> Config Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:25:11 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:25:11 --> URI Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Router Class Initialized
DEBUG - 2012-03-27 18:25:11 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:25:11 --> Output Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Security Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Input Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:25:11 --> Language Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Loader Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:25:11 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Session Class Initialized
DEBUG - 2012-03-27 18:25:11 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:25:11 --> Session routines successfully run
DEBUG - 2012-03-27 18:25:11 --> Controller Class Initialized
DEBUG - 2012-03-27 18:25:11 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:25:11 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 18:25:11 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:25:11 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:25:11 --> Final output sent to browser
DEBUG - 2012-03-27 18:25:11 --> Total execution time: 0.1449
DEBUG - 2012-03-27 18:25:12 --> Config Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:25:12 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:25:12 --> URI Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Router Class Initialized
DEBUG - 2012-03-27 18:25:12 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:25:12 --> Output Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Security Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Input Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:25:12 --> Language Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Loader Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:25:12 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Session Class Initialized
DEBUG - 2012-03-27 18:25:12 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:25:12 --> Session routines successfully run
DEBUG - 2012-03-27 18:25:12 --> Controller Class Initialized
DEBUG - 2012-03-27 18:25:12 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:25:12 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 18:25:12 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:25:12 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:25:12 --> Final output sent to browser
DEBUG - 2012-03-27 18:25:12 --> Total execution time: 0.1570
DEBUG - 2012-03-27 18:25:15 --> Config Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:25:15 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:25:15 --> URI Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Router Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Output Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Security Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Input Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:25:15 --> Language Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Loader Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:25:15 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Session Class Initialized
DEBUG - 2012-03-27 18:25:15 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:25:15 --> Session routines successfully run
DEBUG - 2012-03-27 18:25:15 --> Controller Class Initialized
DEBUG - 2012-03-27 18:25:15 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:25:15 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:25:15 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:25:15 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:25:15 --> Final output sent to browser
DEBUG - 2012-03-27 18:25:15 --> Total execution time: 0.1298
DEBUG - 2012-03-27 18:25:20 --> Config Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:25:20 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:25:20 --> URI Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Router Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Output Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Security Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Input Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:25:20 --> Language Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Loader Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:25:20 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Session Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:25:20 --> Session routines successfully run
DEBUG - 2012-03-27 18:25:20 --> Controller Class Initialized
DEBUG - 2012-03-27 18:25:20 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:25:20 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:28:01 --> Config Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:28:01 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:28:01 --> URI Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Router Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Output Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Security Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Input Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:28:01 --> Language Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Loader Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:28:01 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Session Class Initialized
DEBUG - 2012-03-27 18:28:01 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:28:01 --> Session routines successfully run
DEBUG - 2012-03-27 18:28:01 --> Controller Class Initialized
DEBUG - 2012-03-27 18:28:01 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:28:01 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:28:01 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:28:01 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:28:01 --> Final output sent to browser
DEBUG - 2012-03-27 18:28:01 --> Total execution time: 0.1506
DEBUG - 2012-03-27 18:28:03 --> Config Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:28:03 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:28:03 --> URI Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Router Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Output Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Security Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Input Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:28:03 --> Language Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Loader Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:28:03 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Session Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:28:03 --> Session routines successfully run
DEBUG - 2012-03-27 18:28:03 --> Controller Class Initialized
DEBUG - 2012-03-27 18:28:03 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:28:03 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:29:58 --> Config Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:29:58 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:29:58 --> URI Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Router Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Output Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Security Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Input Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:29:58 --> Language Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Loader Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:29:58 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Session Class Initialized
DEBUG - 2012-03-27 18:29:58 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:29:58 --> Session routines successfully run
DEBUG - 2012-03-27 18:29:58 --> Controller Class Initialized
DEBUG - 2012-03-27 18:29:58 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:29:58 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:29:58 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:29:58 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:29:58 --> Final output sent to browser
DEBUG - 2012-03-27 18:29:58 --> Total execution time: 0.1267
DEBUG - 2012-03-27 18:29:59 --> Config Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:29:59 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:29:59 --> URI Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Router Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Output Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Security Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Input Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:29:59 --> Language Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Loader Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:29:59 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Session Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:29:59 --> Session routines successfully run
DEBUG - 2012-03-27 18:29:59 --> Controller Class Initialized
DEBUG - 2012-03-27 18:29:59 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:29:59 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:30:09 --> Config Class Initialized
DEBUG - 2012-03-27 18:30:09 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:30:09 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:30:09 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:30:09 --> URI Class Initialized
DEBUG - 2012-03-27 18:30:09 --> Router Class Initialized
ERROR - 2012-03-27 18:30:09 --> 404 Page Not Found --> user
DEBUG - 2012-03-27 18:30:15 --> Config Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:30:15 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:30:15 --> URI Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Router Class Initialized
DEBUG - 2012-03-27 18:30:15 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:30:15 --> Output Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Security Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Input Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:30:15 --> Language Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Loader Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:30:15 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Session Class Initialized
DEBUG - 2012-03-27 18:30:15 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:30:15 --> Session routines successfully run
DEBUG - 2012-03-27 18:30:15 --> Controller Class Initialized
DEBUG - 2012-03-27 18:30:15 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:30:15 --> File loaded: application/views/home.php
DEBUG - 2012-03-27 18:30:15 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:30:15 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:30:15 --> Final output sent to browser
DEBUG - 2012-03-27 18:30:15 --> Total execution time: 0.1567
DEBUG - 2012-03-27 18:31:57 --> Config Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:31:57 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:31:57 --> URI Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Router Class Initialized
DEBUG - 2012-03-27 18:31:57 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:31:57 --> Output Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Security Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Input Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:31:57 --> Language Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Loader Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:31:57 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Session Class Initialized
DEBUG - 2012-03-27 18:31:57 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:31:57 --> Session routines successfully run
DEBUG - 2012-03-27 18:31:57 --> Controller Class Initialized
DEBUG - 2012-03-27 18:31:57 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:31:57 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:31:57 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:31:57 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:31:57 --> Final output sent to browser
DEBUG - 2012-03-27 18:31:57 --> Total execution time: 0.1410
DEBUG - 2012-03-27 18:31:58 --> Config Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:31:58 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:31:58 --> URI Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Router Class Initialized
DEBUG - 2012-03-27 18:31:58 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:31:58 --> Output Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Security Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Input Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:31:58 --> Language Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Loader Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:31:58 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Session Class Initialized
DEBUG - 2012-03-27 18:31:58 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:31:58 --> Session routines successfully run
DEBUG - 2012-03-27 18:31:58 --> Controller Class Initialized
DEBUG - 2012-03-27 18:31:58 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:31:58 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:31:58 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:31:58 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:31:58 --> Final output sent to browser
DEBUG - 2012-03-27 18:31:58 --> Total execution time: 0.1403
DEBUG - 2012-03-27 18:31:59 --> Config Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:31:59 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:31:59 --> URI Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Router Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Output Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Security Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Input Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:31:59 --> Language Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Loader Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:31:59 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Session Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:31:59 --> Session routines successfully run
DEBUG - 2012-03-27 18:31:59 --> Controller Class Initialized
DEBUG - 2012-03-27 18:31:59 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:31:59 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:35:05 --> Config Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:35:05 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:35:05 --> URI Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Router Class Initialized
DEBUG - 2012-03-27 18:35:05 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:35:05 --> Output Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Security Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Input Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:35:05 --> Language Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Loader Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:35:05 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Session Class Initialized
DEBUG - 2012-03-27 18:35:05 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:35:05 --> Session routines successfully run
DEBUG - 2012-03-27 18:35:05 --> Controller Class Initialized
DEBUG - 2012-03-27 18:35:05 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:35:05 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:35:05 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:35:05 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:35:05 --> Final output sent to browser
DEBUG - 2012-03-27 18:35:05 --> Total execution time: 0.1590
DEBUG - 2012-03-27 18:35:06 --> Config Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:35:06 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:35:06 --> URI Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Router Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Output Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Security Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Input Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:35:06 --> Language Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Loader Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:35:06 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Session Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:35:06 --> Session routines successfully run
DEBUG - 2012-03-27 18:35:06 --> Controller Class Initialized
DEBUG - 2012-03-27 18:35:06 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:35:06 --> Helper loaded: inflector_helper
DEBUG - 2012-03-27 18:35:13 --> Config Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:35:13 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:35:13 --> URI Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Router Class Initialized
DEBUG - 2012-03-27 18:35:13 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:35:13 --> Output Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Security Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Input Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:35:13 --> Language Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Loader Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:35:13 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Session Class Initialized
DEBUG - 2012-03-27 18:35:13 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:35:13 --> Session routines successfully run
DEBUG - 2012-03-27 18:35:13 --> Controller Class Initialized
DEBUG - 2012-03-27 18:35:13 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:35:13 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:35:13 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:35:13 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:35:13 --> Final output sent to browser
DEBUG - 2012-03-27 18:35:13 --> Total execution time: 0.1556
DEBUG - 2012-03-27 18:35:14 --> Config Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:35:14 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:35:14 --> URI Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Router Class Initialized
DEBUG - 2012-03-27 18:35:14 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:35:14 --> Output Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Security Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Input Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:35:14 --> Language Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Loader Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:35:14 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Session Class Initialized
DEBUG - 2012-03-27 18:35:14 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:35:14 --> Session routines successfully run
DEBUG - 2012-03-27 18:35:14 --> Controller Class Initialized
DEBUG - 2012-03-27 18:35:14 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:35:14 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:35:14 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:35:14 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:35:14 --> Final output sent to browser
DEBUG - 2012-03-27 18:35:14 --> Total execution time: 0.1313
DEBUG - 2012-03-27 18:35:32 --> Config Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:35:32 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:35:32 --> URI Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Router Class Initialized
DEBUG - 2012-03-27 18:35:32 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:35:32 --> Output Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Security Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Input Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:35:32 --> Language Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Loader Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:35:32 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Session Class Initialized
DEBUG - 2012-03-27 18:35:32 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:35:32 --> Session routines successfully run
DEBUG - 2012-03-27 18:35:32 --> Controller Class Initialized
DEBUG - 2012-03-27 18:35:32 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:35:32 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:35:32 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:35:32 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:35:32 --> Final output sent to browser
DEBUG - 2012-03-27 18:35:32 --> Total execution time: 0.1568
DEBUG - 2012-03-27 18:35:33 --> Config Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:35:33 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:35:33 --> URI Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Router Class Initialized
DEBUG - 2012-03-27 18:35:33 --> No URI present. Default controller set.
DEBUG - 2012-03-27 18:35:33 --> Output Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Security Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Input Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:35:33 --> Language Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Loader Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:35:33 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Session Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:35:33 --> Session routines successfully run
DEBUG - 2012-03-27 18:35:33 --> Controller Class Initialized
DEBUG - 2012-03-27 18:35:33 --> File loaded: application/views/header.php
DEBUG - 2012-03-27 18:35:33 --> File loaded: application/views/all_users.php
DEBUG - 2012-03-27 18:35:33 --> File loaded: application/views/footer.php
DEBUG - 2012-03-27 18:35:33 --> File loaded: application/views/layout.php
DEBUG - 2012-03-27 18:35:33 --> Final output sent to browser
DEBUG - 2012-03-27 18:35:33 --> Total execution time: 0.1363
DEBUG - 2012-03-27 18:35:33 --> Config Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Hooks Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Utf8 Class Initialized
DEBUG - 2012-03-27 18:35:33 --> UTF-8 Support Enabled
DEBUG - 2012-03-27 18:35:33 --> URI Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Router Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Output Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Security Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Input Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Global POST and COOKIE data sanitized
DEBUG - 2012-03-27 18:35:33 --> Language Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Loader Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Helper loaded: url_helper
DEBUG - 2012-03-27 18:35:33 --> Unit Testing Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Session Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Helper loaded: string_helper
DEBUG - 2012-03-27 18:35:33 --> Session routines successfully run
DEBUG - 2012-03-27 18:35:33 --> Controller Class Initialized
DEBUG - 2012-03-27 18:35:33 --> Config file loaded: application/config/rest.php
DEBUG - 2012-03-27 18:35:33 --> Helper loaded: inflector_helper
