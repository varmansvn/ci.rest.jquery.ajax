<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-16 05:45:38 --> Config Class Initialized
DEBUG - 2011-09-16 05:45:38 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:45:38 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:45:38 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:45:38 --> URI Class Initialized
DEBUG - 2011-09-16 05:45:38 --> Router Class Initialized
DEBUG - 2011-09-16 05:45:38 --> No URI present. Default controller set.
DEBUG - 2011-09-16 05:45:38 --> Output Class Initialized
DEBUG - 2011-09-16 05:45:38 --> Security Class Initialized
DEBUG - 2011-09-16 05:45:38 --> Input Class Initialized
DEBUG - 2011-09-16 05:45:38 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:45:38 --> Language Class Initialized
DEBUG - 2011-09-16 05:45:39 --> Loader Class Initialized
DEBUG - 2011-09-16 05:45:39 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:45:39 --> Controller Class Initialized
DEBUG - 2011-09-16 05:45:39 --> File loaded: application/views/header.php
DEBUG - 2011-09-16 05:45:39 --> File loaded: application/views/nav.php
DEBUG - 2011-09-16 05:45:39 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-16 05:45:39 --> File loaded: application/views/footer.php
DEBUG - 2011-09-16 05:45:39 --> File loaded: application/views/layout.php
DEBUG - 2011-09-16 05:45:39 --> Final output sent to browser
DEBUG - 2011-09-16 05:45:39 --> Total execution time: 0.8676
DEBUG - 2011-09-16 05:45:41 --> Config Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:45:41 --> URI Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Router Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Output Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Security Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Input Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:45:41 --> Language Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Loader Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:45:41 --> Controller Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Config file loaded: application/config/rest.php
DEBUG - 2011-09-16 05:45:41 --> Helper loaded: inflector_helper
DEBUG - 2011-09-16 05:45:41 --> Config Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:45:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:45:41 --> URI Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Router Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Output Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Security Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Input Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:45:41 --> Language Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Loader Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:45:41 --> Controller Class Initialized
DEBUG - 2011-09-16 05:45:41 --> Config file loaded: application/config/rest.php
DEBUG - 2011-09-16 05:45:41 --> Helper loaded: inflector_helper
DEBUG - 2011-09-16 05:45:43 --> Config Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Hooks Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Utf8 Class Initialized
DEBUG - 2011-09-16 05:45:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 05:45:43 --> URI Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Router Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Output Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Security Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Input Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 05:45:43 --> Language Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Loader Class Initialized
DEBUG - 2011-09-16 05:45:43 --> Helper loaded: url_helper
DEBUG - 2011-09-16 05:45:43 --> Controller Class Initialized
DEBUG - 2011-09-16 05:45:43 --> File loaded: application/views/header.php
DEBUG - 2011-09-16 05:45:43 --> File loaded: application/views/nav.php
DEBUG - 2011-09-16 05:45:43 --> File loaded: application/views/new_user.php
DEBUG - 2011-09-16 05:45:43 --> File loaded: application/views/footer.php
DEBUG - 2011-09-16 05:45:43 --> File loaded: application/views/layout.php
DEBUG - 2011-09-16 05:45:43 --> Final output sent to browser
DEBUG - 2011-09-16 05:45:43 --> Total execution time: 0.1483
DEBUG - 2011-09-16 16:34:17 --> Config Class Initialized
DEBUG - 2011-09-16 16:34:17 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:34:17 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:34:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:34:17 --> URI Class Initialized
DEBUG - 2011-09-16 16:34:17 --> Router Class Initialized
DEBUG - 2011-09-16 16:34:17 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:34:17 --> Output Class Initialized
DEBUG - 2011-09-16 16:34:17 --> Security Class Initialized
DEBUG - 2011-09-16 16:34:17 --> Input Class Initialized
DEBUG - 2011-09-16 16:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:34:17 --> Language Class Initialized
DEBUG - 2011-09-16 16:34:17 --> Loader Class Initialized
DEBUG - 2011-09-16 16:34:17 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:34:17 --> Controller Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Config Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:51:16 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:51:16 --> URI Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Router Class Initialized
DEBUG - 2011-09-16 16:51:16 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:51:16 --> Output Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Security Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Input Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:51:16 --> Language Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Loader Class Initialized
DEBUG - 2011-09-16 16:51:16 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:51:16 --> Controller Class Initialized
DEBUG - 2011-09-16 16:51:16 --> File loaded: application/views/header.php
DEBUG - 2011-09-16 16:51:16 --> File loaded: application/views/nav.php
DEBUG - 2011-09-16 16:51:16 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-16 16:51:16 --> File loaded: application/views/footer.php
DEBUG - 2011-09-16 16:51:16 --> File loaded: application/views/layout.php
DEBUG - 2011-09-16 16:51:16 --> Final output sent to browser
DEBUG - 2011-09-16 16:51:16 --> Total execution time: 0.1298
DEBUG - 2011-09-16 16:54:15 --> Config Class Initialized
DEBUG - 2011-09-16 16:54:15 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:54:15 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:54:15 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:54:15 --> URI Class Initialized
DEBUG - 2011-09-16 16:54:15 --> Router Class Initialized
DEBUG - 2011-09-16 16:54:15 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:54:15 --> Output Class Initialized
DEBUG - 2011-09-16 16:54:15 --> Security Class Initialized
DEBUG - 2011-09-16 16:54:15 --> Input Class Initialized
DEBUG - 2011-09-16 16:54:15 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:54:15 --> Language Class Initialized
DEBUG - 2011-09-16 16:54:15 --> Loader Class Initialized
DEBUG - 2011-09-16 16:54:15 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:54:15 --> Controller Class Initialized
ERROR - 2011-09-16 16:54:15 --> Severity: Notice  --> Undefined variable: status D:\dev\web\vcib\application\views\layout.php 8
DEBUG - 2011-09-16 16:54:15 --> File loaded: application/views/header.php
DEBUG - 2011-09-16 16:54:15 --> File loaded: application/views/nav.php
DEBUG - 2011-09-16 16:54:15 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-16 16:54:15 --> File loaded: application/views/footer.php
DEBUG - 2011-09-16 16:54:15 --> File loaded: application/views/layout.php
DEBUG - 2011-09-16 16:54:15 --> Final output sent to browser
DEBUG - 2011-09-16 16:54:15 --> Total execution time: 0.1699
DEBUG - 2011-09-16 16:54:23 --> Config Class Initialized
DEBUG - 2011-09-16 16:54:23 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:54:23 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:54:23 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:54:23 --> URI Class Initialized
DEBUG - 2011-09-16 16:54:23 --> Router Class Initialized
DEBUG - 2011-09-16 16:54:23 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:54:23 --> Output Class Initialized
DEBUG - 2011-09-16 16:54:23 --> Security Class Initialized
DEBUG - 2011-09-16 16:54:23 --> Input Class Initialized
DEBUG - 2011-09-16 16:54:23 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:54:23 --> Language Class Initialized
DEBUG - 2011-09-16 16:54:23 --> Loader Class Initialized
DEBUG - 2011-09-16 16:54:23 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:54:23 --> Controller Class Initialized
ERROR - 2011-09-16 16:54:23 --> Severity: Notice  --> Undefined variable: status D:\dev\web\vcib\application\views\layout.php 8
DEBUG - 2011-09-16 16:54:23 --> File loaded: application/views/header.php
DEBUG - 2011-09-16 16:54:23 --> File loaded: application/views/nav.php
DEBUG - 2011-09-16 16:54:23 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-16 16:54:23 --> File loaded: application/views/footer.php
DEBUG - 2011-09-16 16:54:23 --> File loaded: application/views/layout.php
DEBUG - 2011-09-16 16:54:23 --> Final output sent to browser
DEBUG - 2011-09-16 16:54:23 --> Total execution time: 0.2578
DEBUG - 2011-09-16 16:54:25 --> Config Class Initialized
DEBUG - 2011-09-16 16:54:25 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:54:25 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:54:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:54:25 --> URI Class Initialized
DEBUG - 2011-09-16 16:54:25 --> Router Class Initialized
DEBUG - 2011-09-16 16:54:25 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:54:25 --> Output Class Initialized
DEBUG - 2011-09-16 16:54:25 --> Security Class Initialized
DEBUG - 2011-09-16 16:54:25 --> Input Class Initialized
DEBUG - 2011-09-16 16:54:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:54:25 --> Language Class Initialized
DEBUG - 2011-09-16 16:54:25 --> Loader Class Initialized
DEBUG - 2011-09-16 16:54:25 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:54:25 --> Controller Class Initialized
ERROR - 2011-09-16 16:54:25 --> Severity: Notice  --> Undefined variable: status D:\dev\web\vcib\application\views\layout.php 8
DEBUG - 2011-09-16 16:54:25 --> File loaded: application/views/header.php
DEBUG - 2011-09-16 16:54:25 --> File loaded: application/views/nav.php
DEBUG - 2011-09-16 16:54:25 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-16 16:54:25 --> File loaded: application/views/footer.php
DEBUG - 2011-09-16 16:54:25 --> File loaded: application/views/layout.php
DEBUG - 2011-09-16 16:54:25 --> Final output sent to browser
DEBUG - 2011-09-16 16:54:25 --> Total execution time: 0.1711
DEBUG - 2011-09-16 16:55:10 --> Config Class Initialized
DEBUG - 2011-09-16 16:55:10 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:55:10 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:55:10 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:55:10 --> URI Class Initialized
DEBUG - 2011-09-16 16:55:10 --> Router Class Initialized
DEBUG - 2011-09-16 16:55:10 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:55:10 --> Output Class Initialized
DEBUG - 2011-09-16 16:55:10 --> Security Class Initialized
DEBUG - 2011-09-16 16:55:10 --> Input Class Initialized
DEBUG - 2011-09-16 16:55:10 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:55:10 --> Language Class Initialized
DEBUG - 2011-09-16 16:55:10 --> Loader Class Initialized
DEBUG - 2011-09-16 16:55:10 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:55:10 --> Controller Class Initialized
DEBUG - 2011-09-16 16:55:10 --> File loaded: application/views/header.php
DEBUG - 2011-09-16 16:55:10 --> File loaded: application/views/nav.php
DEBUG - 2011-09-16 16:55:10 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-16 16:55:10 --> File loaded: application/views/footer.php
DEBUG - 2011-09-16 16:55:10 --> File loaded: application/views/layout.php
DEBUG - 2011-09-16 16:55:10 --> Final output sent to browser
DEBUG - 2011-09-16 16:55:10 --> Total execution time: 0.2546
DEBUG - 2011-09-16 16:56:09 --> Config Class Initialized
DEBUG - 2011-09-16 16:56:09 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:56:09 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:56:09 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:56:09 --> URI Class Initialized
DEBUG - 2011-09-16 16:56:09 --> Router Class Initialized
DEBUG - 2011-09-16 16:56:09 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:56:09 --> Output Class Initialized
DEBUG - 2011-09-16 16:56:09 --> Security Class Initialized
DEBUG - 2011-09-16 16:56:09 --> Input Class Initialized
DEBUG - 2011-09-16 16:56:09 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:56:09 --> Language Class Initialized
DEBUG - 2011-09-16 16:56:09 --> Loader Class Initialized
DEBUG - 2011-09-16 16:56:09 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:56:09 --> Controller Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Config Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:56:43 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:56:43 --> URI Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Router Class Initialized
DEBUG - 2011-09-16 16:56:43 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:56:43 --> Output Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Security Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Input Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:56:43 --> Language Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Loader Class Initialized
DEBUG - 2011-09-16 16:56:43 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:56:43 --> Controller Class Initialized
ERROR - 2011-09-16 16:56:43 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class ..\models\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 16:56:43 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 16:56:43 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 16:57:20 --> Config Class Initialized
DEBUG - 2011-09-16 16:57:20 --> Hooks Class Initialized
DEBUG - 2011-09-16 16:57:20 --> Utf8 Class Initialized
DEBUG - 2011-09-16 16:57:20 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 16:57:20 --> URI Class Initialized
DEBUG - 2011-09-16 16:57:20 --> Router Class Initialized
DEBUG - 2011-09-16 16:57:20 --> No URI present. Default controller set.
DEBUG - 2011-09-16 16:57:20 --> Output Class Initialized
DEBUG - 2011-09-16 16:57:20 --> Security Class Initialized
DEBUG - 2011-09-16 16:57:20 --> Input Class Initialized
DEBUG - 2011-09-16 16:57:20 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 16:57:20 --> Language Class Initialized
DEBUG - 2011-09-16 16:57:20 --> Loader Class Initialized
DEBUG - 2011-09-16 16:57:20 --> Helper loaded: url_helper
DEBUG - 2011-09-16 16:57:20 --> Controller Class Initialized
ERROR - 2011-09-16 16:57:20 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 16:57:20 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 16:57:20 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:01:21 --> Config Class Initialized
DEBUG - 2011-09-16 17:01:21 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:01:21 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:01:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:01:21 --> URI Class Initialized
DEBUG - 2011-09-16 17:01:21 --> Router Class Initialized
DEBUG - 2011-09-16 17:01:21 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:01:21 --> Output Class Initialized
DEBUG - 2011-09-16 17:01:21 --> Security Class Initialized
DEBUG - 2011-09-16 17:01:21 --> Input Class Initialized
DEBUG - 2011-09-16 17:01:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:01:21 --> Language Class Initialized
DEBUG - 2011-09-16 17:01:21 --> Loader Class Initialized
DEBUG - 2011-09-16 17:01:21 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:01:21 --> Controller Class Initialized
ERROR - 2011-09-16 17:01:21 --> Severity: Notice  --> Undefined variable: repo D:\dev\web\vcib\application\controllers\users.php 25
DEBUG - 2011-09-16 17:01:21 --> File loaded: application/views/header.php
DEBUG - 2011-09-16 17:01:21 --> File loaded: application/views/nav.php
DEBUG - 2011-09-16 17:01:21 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-16 17:01:21 --> File loaded: application/views/footer.php
DEBUG - 2011-09-16 17:01:21 --> File loaded: application/views/layout.php
DEBUG - 2011-09-16 17:01:21 --> Final output sent to browser
DEBUG - 2011-09-16 17:01:21 --> Total execution time: 0.2550
DEBUG - 2011-09-16 17:02:19 --> Config Class Initialized
DEBUG - 2011-09-16 17:02:19 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:02:19 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:02:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:02:19 --> URI Class Initialized
DEBUG - 2011-09-16 17:02:19 --> Router Class Initialized
DEBUG - 2011-09-16 17:02:19 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:02:19 --> Output Class Initialized
DEBUG - 2011-09-16 17:02:19 --> Security Class Initialized
DEBUG - 2011-09-16 17:02:19 --> Input Class Initialized
DEBUG - 2011-09-16 17:02:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:02:19 --> Language Class Initialized
DEBUG - 2011-09-16 17:02:19 --> Loader Class Initialized
DEBUG - 2011-09-16 17:02:19 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:02:19 --> Controller Class Initialized
ERROR - 2011-09-16 17:02:19 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class application\models\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:02:19 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:02:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:03:00 --> Config Class Initialized
DEBUG - 2011-09-16 17:03:00 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:03:00 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:03:00 --> URI Class Initialized
DEBUG - 2011-09-16 17:03:00 --> Router Class Initialized
DEBUG - 2011-09-16 17:03:00 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:03:00 --> Output Class Initialized
DEBUG - 2011-09-16 17:03:00 --> Security Class Initialized
DEBUG - 2011-09-16 17:03:00 --> Input Class Initialized
DEBUG - 2011-09-16 17:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:03:00 --> Language Class Initialized
DEBUG - 2011-09-16 17:03:00 --> Loader Class Initialized
DEBUG - 2011-09-16 17:03:00 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:03:00 --> Controller Class Initialized
ERROR - 2011-09-16 17:03:00 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class application/models/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:03:00 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:03:00 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:25:31 --> Config Class Initialized
DEBUG - 2011-09-16 17:25:31 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:25:31 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:25:31 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:25:31 --> URI Class Initialized
DEBUG - 2011-09-16 17:25:31 --> Router Class Initialized
DEBUG - 2011-09-16 17:25:31 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:25:31 --> Output Class Initialized
DEBUG - 2011-09-16 17:25:31 --> Security Class Initialized
DEBUG - 2011-09-16 17:25:31 --> Input Class Initialized
DEBUG - 2011-09-16 17:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:25:31 --> Language Class Initialized
DEBUG - 2011-09-16 17:25:31 --> Loader Class Initialized
DEBUG - 2011-09-16 17:25:31 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:25:32 --> Controller Class Initialized
ERROR - 2011-09-16 17:25:32 --> Severity: Warning  --> require(application/models\Entities\UserRepository.php) [<a href='function.require'>function.require</a>]: failed to open stream: No such file or directory D:\dev\web\vcib\application\libraries\Doctrine\Common\ClassLoader.php 148
DEBUG - 2011-09-16 17:28:55 --> Config Class Initialized
DEBUG - 2011-09-16 17:28:55 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:28:55 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:28:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:28:55 --> URI Class Initialized
DEBUG - 2011-09-16 17:28:55 --> Router Class Initialized
DEBUG - 2011-09-16 17:28:55 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:28:55 --> Output Class Initialized
DEBUG - 2011-09-16 17:28:55 --> Security Class Initialized
DEBUG - 2011-09-16 17:28:55 --> Input Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:28:56 --> Language Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Loader Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:28:56 --> Controller Class Initialized
ERROR - 2011-09-16 17:28:56 --> Severity: Warning  --> require(application/models\Entities\UserRepository.php) [<a href='function.require'>function.require</a>]: failed to open stream: No such file or directory D:\dev\web\vcib\application\libraries\Doctrine\Common\ClassLoader.php 148
DEBUG - 2011-09-16 17:28:56 --> Config Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:28:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:28:56 --> URI Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Router Class Initialized
DEBUG - 2011-09-16 17:28:56 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:28:56 --> Output Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Security Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Input Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:28:56 --> Language Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Loader Class Initialized
DEBUG - 2011-09-16 17:28:56 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:28:57 --> Controller Class Initialized
ERROR - 2011-09-16 17:28:57 --> Severity: Warning  --> require(application/models\Entities\UserRepository.php) [<a href='function.require'>function.require</a>]: failed to open stream: No such file or directory D:\dev\web\vcib\application\libraries\Doctrine\Common\ClassLoader.php 148
DEBUG - 2011-09-16 17:29:34 --> Config Class Initialized
DEBUG - 2011-09-16 17:29:34 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:29:34 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:29:34 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:29:34 --> URI Class Initialized
DEBUG - 2011-09-16 17:29:34 --> Router Class Initialized
DEBUG - 2011-09-16 17:29:34 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:29:34 --> Output Class Initialized
DEBUG - 2011-09-16 17:29:34 --> Security Class Initialized
DEBUG - 2011-09-16 17:29:34 --> Input Class Initialized
DEBUG - 2011-09-16 17:29:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:29:34 --> Language Class Initialized
DEBUG - 2011-09-16 17:29:34 --> Loader Class Initialized
DEBUG - 2011-09-16 17:29:34 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:29:34 --> Controller Class Initialized
ERROR - 2011-09-16 17:29:34 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:29:34 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:29:34 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:30:56 --> Config Class Initialized
DEBUG - 2011-09-16 17:30:56 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:30:56 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:30:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:30:56 --> URI Class Initialized
DEBUG - 2011-09-16 17:30:56 --> Router Class Initialized
DEBUG - 2011-09-16 17:30:56 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:30:56 --> Output Class Initialized
DEBUG - 2011-09-16 17:30:56 --> Security Class Initialized
DEBUG - 2011-09-16 17:30:56 --> Input Class Initialized
DEBUG - 2011-09-16 17:30:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:30:56 --> Language Class Initialized
DEBUG - 2011-09-16 17:30:56 --> Loader Class Initialized
DEBUG - 2011-09-16 17:30:56 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:30:56 --> Controller Class Initialized
ERROR - 2011-09-16 17:30:57 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:30:57 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:30:57 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:30:57 --> Config Class Initialized
DEBUG - 2011-09-16 17:30:57 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:30:57 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:30:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:30:57 --> URI Class Initialized
DEBUG - 2011-09-16 17:30:57 --> Router Class Initialized
DEBUG - 2011-09-16 17:30:57 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:30:57 --> Output Class Initialized
DEBUG - 2011-09-16 17:30:57 --> Security Class Initialized
DEBUG - 2011-09-16 17:30:57 --> Input Class Initialized
DEBUG - 2011-09-16 17:30:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:30:57 --> Language Class Initialized
DEBUG - 2011-09-16 17:30:57 --> Loader Class Initialized
DEBUG - 2011-09-16 17:30:57 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:30:57 --> Controller Class Initialized
ERROR - 2011-09-16 17:30:57 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:30:57 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:30:57 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:30:58 --> Config Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:30:58 --> URI Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Router Class Initialized
DEBUG - 2011-09-16 17:30:58 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:30:58 --> Output Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Security Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Input Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:30:58 --> Language Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Loader Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:30:58 --> Controller Class Initialized
ERROR - 2011-09-16 17:30:58 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:30:58 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:30:58 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:30:58 --> Config Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:30:58 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:30:58 --> URI Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Router Class Initialized
DEBUG - 2011-09-16 17:30:58 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:30:58 --> Output Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Security Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Input Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:30:58 --> Language Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Loader Class Initialized
DEBUG - 2011-09-16 17:30:58 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:30:58 --> Controller Class Initialized
ERROR - 2011-09-16 17:30:58 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:30:58 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:30:58 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:33:30 --> Config Class Initialized
DEBUG - 2011-09-16 17:33:30 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:33:30 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:33:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:33:30 --> URI Class Initialized
DEBUG - 2011-09-16 17:33:30 --> Router Class Initialized
DEBUG - 2011-09-16 17:33:30 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:33:30 --> Output Class Initialized
DEBUG - 2011-09-16 17:33:30 --> Security Class Initialized
DEBUG - 2011-09-16 17:33:30 --> Input Class Initialized
DEBUG - 2011-09-16 17:33:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:33:30 --> Language Class Initialized
DEBUG - 2011-09-16 17:33:30 --> Loader Class Initialized
DEBUG - 2011-09-16 17:33:30 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:33:30 --> Controller Class Initialized
ERROR - 2011-09-16 17:33:30 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:33:30 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:33:30 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:33:33 --> Config Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:33:33 --> URI Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Router Class Initialized
DEBUG - 2011-09-16 17:33:33 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:33:33 --> Output Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Security Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Input Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:33:33 --> Language Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Loader Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:33:33 --> Controller Class Initialized
ERROR - 2011-09-16 17:33:33 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:33:33 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:33:33 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:33:33 --> Config Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:33:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:33:33 --> URI Class Initialized
DEBUG - 2011-09-16 17:33:33 --> Router Class Initialized
DEBUG - 2011-09-16 17:33:34 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:33:34 --> Output Class Initialized
DEBUG - 2011-09-16 17:33:34 --> Security Class Initialized
DEBUG - 2011-09-16 17:33:34 --> Input Class Initialized
DEBUG - 2011-09-16 17:33:34 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:33:34 --> Language Class Initialized
DEBUG - 2011-09-16 17:33:34 --> Loader Class Initialized
DEBUG - 2011-09-16 17:33:34 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:33:34 --> Controller Class Initialized
ERROR - 2011-09-16 17:33:34 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:33:34 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:33:34 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:34:25 --> Config Class Initialized
DEBUG - 2011-09-16 17:34:25 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:34:25 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:34:25 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:34:25 --> URI Class Initialized
DEBUG - 2011-09-16 17:34:25 --> Router Class Initialized
DEBUG - 2011-09-16 17:34:25 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:34:25 --> Output Class Initialized
DEBUG - 2011-09-16 17:34:25 --> Security Class Initialized
DEBUG - 2011-09-16 17:34:25 --> Input Class Initialized
DEBUG - 2011-09-16 17:34:25 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:34:25 --> Language Class Initialized
DEBUG - 2011-09-16 17:34:25 --> Loader Class Initialized
DEBUG - 2011-09-16 17:34:25 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:34:26 --> Controller Class Initialized
ERROR - 2011-09-16 17:34:26 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:34:26 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:34:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:34:27 --> Config Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:34:27 --> URI Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Router Class Initialized
DEBUG - 2011-09-16 17:34:27 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:34:27 --> Output Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Security Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Input Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:34:27 --> Language Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Loader Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:34:27 --> Controller Class Initialized
ERROR - 2011-09-16 17:34:27 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:34:27 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:34:27 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:34:27 --> Config Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:34:27 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:34:27 --> URI Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Router Class Initialized
DEBUG - 2011-09-16 17:34:27 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:34:27 --> Output Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Security Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Input Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:34:27 --> Language Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Loader Class Initialized
DEBUG - 2011-09-16 17:34:27 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:34:27 --> Controller Class Initialized
ERROR - 2011-09-16 17:34:27 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:34:27 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:34:27 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 17:34:28 --> Config Class Initialized
DEBUG - 2011-09-16 17:34:28 --> Hooks Class Initialized
DEBUG - 2011-09-16 17:34:28 --> Utf8 Class Initialized
DEBUG - 2011-09-16 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 17:34:28 --> URI Class Initialized
DEBUG - 2011-09-16 17:34:28 --> Router Class Initialized
DEBUG - 2011-09-16 17:34:28 --> No URI present. Default controller set.
DEBUG - 2011-09-16 17:34:28 --> Output Class Initialized
DEBUG - 2011-09-16 17:34:28 --> Security Class Initialized
DEBUG - 2011-09-16 17:34:28 --> Input Class Initialized
DEBUG - 2011-09-16 17:34:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 17:34:28 --> Language Class Initialized
DEBUG - 2011-09-16 17:34:28 --> Loader Class Initialized
DEBUG - 2011-09-16 17:34:28 --> Helper loaded: url_helper
DEBUG - 2011-09-16 17:34:28 --> Controller Class Initialized
ERROR - 2011-09-16 17:34:28 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:34:28 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 17:34:28 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:12:46 --> Config Class Initialized
DEBUG - 2011-09-16 18:12:46 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:12:46 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:12:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:12:46 --> URI Class Initialized
DEBUG - 2011-09-16 18:12:46 --> Router Class Initialized
DEBUG - 2011-09-16 18:12:46 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:12:46 --> Output Class Initialized
DEBUG - 2011-09-16 18:12:46 --> Security Class Initialized
DEBUG - 2011-09-16 18:12:46 --> Input Class Initialized
DEBUG - 2011-09-16 18:12:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:12:46 --> Language Class Initialized
DEBUG - 2011-09-16 18:12:46 --> Loader Class Initialized
DEBUG - 2011-09-16 18:12:46 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:12:46 --> Controller Class Initialized
ERROR - 2011-09-16 18:12:46 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:12:46 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:12:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:12:47 --> Config Class Initialized
DEBUG - 2011-09-16 18:12:47 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:12:47 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:12:47 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:12:47 --> URI Class Initialized
DEBUG - 2011-09-16 18:12:47 --> Router Class Initialized
DEBUG - 2011-09-16 18:12:47 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:12:47 --> Output Class Initialized
DEBUG - 2011-09-16 18:12:47 --> Security Class Initialized
DEBUG - 2011-09-16 18:12:47 --> Input Class Initialized
DEBUG - 2011-09-16 18:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:12:47 --> Language Class Initialized
DEBUG - 2011-09-16 18:12:47 --> Loader Class Initialized
DEBUG - 2011-09-16 18:12:47 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:12:47 --> Controller Class Initialized
ERROR - 2011-09-16 18:12:47 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:12:47 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:12:47 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:12:48 --> Config Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:12:48 --> URI Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Router Class Initialized
DEBUG - 2011-09-16 18:12:48 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:12:48 --> Output Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Security Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Input Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:12:48 --> Language Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Loader Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:12:48 --> Controller Class Initialized
ERROR - 2011-09-16 18:12:48 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:12:48 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:12:48 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:12:48 --> Config Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:12:48 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:12:48 --> URI Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Router Class Initialized
DEBUG - 2011-09-16 18:12:48 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:12:48 --> Output Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Security Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Input Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:12:48 --> Language Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Loader Class Initialized
DEBUG - 2011-09-16 18:12:48 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:12:48 --> Controller Class Initialized
ERROR - 2011-09-16 18:12:48 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:12:48 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:12:48 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:13:46 --> Config Class Initialized
DEBUG - 2011-09-16 18:13:46 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:13:46 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:13:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:13:46 --> URI Class Initialized
DEBUG - 2011-09-16 18:13:46 --> Router Class Initialized
DEBUG - 2011-09-16 18:13:46 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:13:46 --> Output Class Initialized
DEBUG - 2011-09-16 18:13:46 --> Security Class Initialized
DEBUG - 2011-09-16 18:13:46 --> Input Class Initialized
DEBUG - 2011-09-16 18:13:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:13:46 --> Language Class Initialized
DEBUG - 2011-09-16 18:13:46 --> Loader Class Initialized
DEBUG - 2011-09-16 18:13:46 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:13:46 --> Controller Class Initialized
ERROR - 2011-09-16 18:13:46 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:13:46 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:13:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:14:41 --> Config Class Initialized
DEBUG - 2011-09-16 18:14:41 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:14:41 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:14:41 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:14:41 --> URI Class Initialized
DEBUG - 2011-09-16 18:14:41 --> Router Class Initialized
DEBUG - 2011-09-16 18:14:41 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:14:41 --> Output Class Initialized
DEBUG - 2011-09-16 18:14:41 --> Security Class Initialized
DEBUG - 2011-09-16 18:14:41 --> Input Class Initialized
DEBUG - 2011-09-16 18:14:41 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:14:41 --> Language Class Initialized
DEBUG - 2011-09-16 18:14:41 --> Loader Class Initialized
DEBUG - 2011-09-16 18:14:41 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:14:41 --> Controller Class Initialized
ERROR - 2011-09-16 18:14:41 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:14:41 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:14:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:23:05 --> Config Class Initialized
DEBUG - 2011-09-16 18:23:05 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:23:05 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:23:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:23:05 --> URI Class Initialized
DEBUG - 2011-09-16 18:23:05 --> Router Class Initialized
DEBUG - 2011-09-16 18:23:05 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:23:05 --> Output Class Initialized
DEBUG - 2011-09-16 18:23:05 --> Security Class Initialized
DEBUG - 2011-09-16 18:23:05 --> Input Class Initialized
DEBUG - 2011-09-16 18:23:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:23:05 --> Language Class Initialized
DEBUG - 2011-09-16 18:23:05 --> Loader Class Initialized
DEBUG - 2011-09-16 18:23:05 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:23:05 --> Controller Class Initialized
ERROR - 2011-09-16 18:23:05 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:23:05 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:23:05 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:23:07 --> Config Class Initialized
DEBUG - 2011-09-16 18:23:07 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:23:07 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:23:07 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:23:07 --> URI Class Initialized
DEBUG - 2011-09-16 18:23:07 --> Router Class Initialized
DEBUG - 2011-09-16 18:23:07 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:23:07 --> Output Class Initialized
DEBUG - 2011-09-16 18:23:07 --> Security Class Initialized
DEBUG - 2011-09-16 18:23:07 --> Input Class Initialized
DEBUG - 2011-09-16 18:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:23:07 --> Language Class Initialized
DEBUG - 2011-09-16 18:23:07 --> Loader Class Initialized
DEBUG - 2011-09-16 18:23:07 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:23:07 --> Controller Class Initialized
ERROR - 2011-09-16 18:23:07 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:23:07 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:23:07 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:54:28 --> Config Class Initialized
DEBUG - 2011-09-16 18:54:28 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:54:28 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:54:28 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:54:28 --> URI Class Initialized
DEBUG - 2011-09-16 18:54:28 --> Router Class Initialized
DEBUG - 2011-09-16 18:54:28 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:54:28 --> Output Class Initialized
DEBUG - 2011-09-16 18:54:28 --> Security Class Initialized
DEBUG - 2011-09-16 18:54:28 --> Input Class Initialized
DEBUG - 2011-09-16 18:54:28 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:54:28 --> Language Class Initialized
DEBUG - 2011-09-16 18:54:28 --> Loader Class Initialized
DEBUG - 2011-09-16 18:54:28 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:54:28 --> Controller Class Initialized
ERROR - 2011-09-16 18:54:28 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:54:28 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:54:28 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:56:03 --> Config Class Initialized
DEBUG - 2011-09-16 18:56:03 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:56:03 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:56:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:56:03 --> URI Class Initialized
DEBUG - 2011-09-16 18:56:03 --> Router Class Initialized
DEBUG - 2011-09-16 18:56:03 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:56:03 --> Output Class Initialized
DEBUG - 2011-09-16 18:56:03 --> Security Class Initialized
DEBUG - 2011-09-16 18:56:03 --> Input Class Initialized
DEBUG - 2011-09-16 18:56:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:56:03 --> Language Class Initialized
DEBUG - 2011-09-16 18:56:03 --> Loader Class Initialized
DEBUG - 2011-09-16 18:56:03 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:56:04 --> Controller Class Initialized
ERROR - 2011-09-16 18:56:04 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:04 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:04 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:56:05 --> Config Class Initialized
DEBUG - 2011-09-16 18:56:05 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:56:05 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:56:05 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:56:05 --> URI Class Initialized
DEBUG - 2011-09-16 18:56:05 --> Router Class Initialized
DEBUG - 2011-09-16 18:56:05 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:56:05 --> Output Class Initialized
DEBUG - 2011-09-16 18:56:05 --> Security Class Initialized
DEBUG - 2011-09-16 18:56:05 --> Input Class Initialized
DEBUG - 2011-09-16 18:56:05 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:56:05 --> Language Class Initialized
DEBUG - 2011-09-16 18:56:05 --> Loader Class Initialized
DEBUG - 2011-09-16 18:56:05 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:56:05 --> Controller Class Initialized
ERROR - 2011-09-16 18:56:05 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class repositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:05 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:05 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:56:19 --> Config Class Initialized
DEBUG - 2011-09-16 18:56:19 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:56:19 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:56:19 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:56:19 --> URI Class Initialized
DEBUG - 2011-09-16 18:56:19 --> Router Class Initialized
DEBUG - 2011-09-16 18:56:19 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:56:19 --> Output Class Initialized
DEBUG - 2011-09-16 18:56:19 --> Security Class Initialized
DEBUG - 2011-09-16 18:56:19 --> Input Class Initialized
DEBUG - 2011-09-16 18:56:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:56:19 --> Language Class Initialized
DEBUG - 2011-09-16 18:56:19 --> Loader Class Initialized
DEBUG - 2011-09-16 18:56:19 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:56:19 --> Controller Class Initialized
ERROR - 2011-09-16 18:56:19 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:19 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:56:45 --> Config Class Initialized
DEBUG - 2011-09-16 18:56:45 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:56:45 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:56:45 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:56:45 --> URI Class Initialized
DEBUG - 2011-09-16 18:56:45 --> Router Class Initialized
DEBUG - 2011-09-16 18:56:45 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:56:45 --> Output Class Initialized
DEBUG - 2011-09-16 18:56:45 --> Security Class Initialized
DEBUG - 2011-09-16 18:56:45 --> Input Class Initialized
DEBUG - 2011-09-16 18:56:45 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:56:45 --> Language Class Initialized
DEBUG - 2011-09-16 18:56:45 --> Loader Class Initialized
DEBUG - 2011-09-16 18:56:45 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:56:45 --> Controller Class Initialized
ERROR - 2011-09-16 18:56:45 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class modelsepositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:45 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:45 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:56:46 --> Config Class Initialized
DEBUG - 2011-09-16 18:56:46 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:56:46 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:56:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:56:46 --> URI Class Initialized
DEBUG - 2011-09-16 18:56:46 --> Router Class Initialized
DEBUG - 2011-09-16 18:56:46 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:56:46 --> Output Class Initialized
DEBUG - 2011-09-16 18:56:46 --> Security Class Initialized
DEBUG - 2011-09-16 18:56:46 --> Input Class Initialized
DEBUG - 2011-09-16 18:56:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:56:46 --> Language Class Initialized
DEBUG - 2011-09-16 18:56:46 --> Loader Class Initialized
DEBUG - 2011-09-16 18:56:46 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:56:46 --> Controller Class Initialized
ERROR - 2011-09-16 18:56:47 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class modelsepositories\UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:47 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:56:47 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:57:01 --> Config Class Initialized
DEBUG - 2011-09-16 18:57:01 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:57:01 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:57:02 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:57:02 --> URI Class Initialized
DEBUG - 2011-09-16 18:57:02 --> Router Class Initialized
DEBUG - 2011-09-16 18:57:02 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:57:02 --> Output Class Initialized
DEBUG - 2011-09-16 18:57:02 --> Security Class Initialized
DEBUG - 2011-09-16 18:57:02 --> Input Class Initialized
DEBUG - 2011-09-16 18:57:02 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:57:02 --> Language Class Initialized
DEBUG - 2011-09-16 18:57:02 --> Loader Class Initialized
DEBUG - 2011-09-16 18:57:02 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:57:02 --> Controller Class Initialized
ERROR - 2011-09-16 18:57:02 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class models/repositories/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:57:02 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:57:02 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:57:03 --> Config Class Initialized
DEBUG - 2011-09-16 18:57:03 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:57:03 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:57:03 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:57:03 --> URI Class Initialized
DEBUG - 2011-09-16 18:57:03 --> Router Class Initialized
DEBUG - 2011-09-16 18:57:03 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:57:03 --> Output Class Initialized
DEBUG - 2011-09-16 18:57:03 --> Security Class Initialized
DEBUG - 2011-09-16 18:57:03 --> Input Class Initialized
DEBUG - 2011-09-16 18:57:03 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:57:03 --> Language Class Initialized
DEBUG - 2011-09-16 18:57:03 --> Loader Class Initialized
DEBUG - 2011-09-16 18:57:03 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:57:03 --> Controller Class Initialized
ERROR - 2011-09-16 18:57:03 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class models/repositories/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:57:03 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:57:03 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 18:58:21 --> Config Class Initialized
DEBUG - 2011-09-16 18:58:21 --> Hooks Class Initialized
DEBUG - 2011-09-16 18:58:21 --> Utf8 Class Initialized
DEBUG - 2011-09-16 18:58:21 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 18:58:21 --> URI Class Initialized
DEBUG - 2011-09-16 18:58:21 --> Router Class Initialized
DEBUG - 2011-09-16 18:58:21 --> No URI present. Default controller set.
DEBUG - 2011-09-16 18:58:21 --> Output Class Initialized
DEBUG - 2011-09-16 18:58:21 --> Security Class Initialized
DEBUG - 2011-09-16 18:58:21 --> Input Class Initialized
DEBUG - 2011-09-16 18:58:21 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 18:58:21 --> Language Class Initialized
DEBUG - 2011-09-16 18:58:21 --> Loader Class Initialized
DEBUG - 2011-09-16 18:58:21 --> Helper loaded: url_helper
DEBUG - 2011-09-16 18:58:21 --> Controller Class Initialized
ERROR - 2011-09-16 18:58:21 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class application/models/repositories/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:58:21 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 18:58:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 19:18:17 --> Config Class Initialized
DEBUG - 2011-09-16 19:18:17 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:18:17 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:18:17 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:18:17 --> URI Class Initialized
DEBUG - 2011-09-16 19:18:17 --> Router Class Initialized
DEBUG - 2011-09-16 19:18:17 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:18:17 --> Output Class Initialized
DEBUG - 2011-09-16 19:18:17 --> Security Class Initialized
DEBUG - 2011-09-16 19:18:17 --> Input Class Initialized
DEBUG - 2011-09-16 19:18:17 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:18:17 --> Language Class Initialized
DEBUG - 2011-09-16 19:18:17 --> Loader Class Initialized
DEBUG - 2011-09-16 19:18:17 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:18:17 --> Controller Class Initialized
ERROR - 2011-09-16 19:18:17 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class application/models/repositories/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:17 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:17 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 19:18:18 --> Config Class Initialized
DEBUG - 2011-09-16 19:18:18 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:18:18 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:18:18 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:18:18 --> URI Class Initialized
DEBUG - 2011-09-16 19:18:18 --> Router Class Initialized
DEBUG - 2011-09-16 19:18:18 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:18:19 --> Output Class Initialized
DEBUG - 2011-09-16 19:18:19 --> Security Class Initialized
DEBUG - 2011-09-16 19:18:19 --> Input Class Initialized
DEBUG - 2011-09-16 19:18:19 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:18:19 --> Language Class Initialized
DEBUG - 2011-09-16 19:18:19 --> Loader Class Initialized
DEBUG - 2011-09-16 19:18:19 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:18:19 --> Controller Class Initialized
ERROR - 2011-09-16 19:18:19 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class application/models/repositories/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:19 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:19 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 19:18:32 --> Config Class Initialized
DEBUG - 2011-09-16 19:18:32 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:18:32 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:18:32 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:18:32 --> URI Class Initialized
DEBUG - 2011-09-16 19:18:32 --> Router Class Initialized
DEBUG - 2011-09-16 19:18:32 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:18:32 --> Output Class Initialized
DEBUG - 2011-09-16 19:18:32 --> Security Class Initialized
DEBUG - 2011-09-16 19:18:32 --> Input Class Initialized
DEBUG - 2011-09-16 19:18:32 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:18:32 --> Language Class Initialized
DEBUG - 2011-09-16 19:18:32 --> Loader Class Initialized
DEBUG - 2011-09-16 19:18:32 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:18:32 --> Controller Class Initialized
ERROR - 2011-09-16 19:18:32 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Entities/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:32 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:32 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 19:18:33 --> Config Class Initialized
DEBUG - 2011-09-16 19:18:33 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:18:33 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:18:33 --> URI Class Initialized
DEBUG - 2011-09-16 19:18:33 --> Router Class Initialized
DEBUG - 2011-09-16 19:18:33 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:18:33 --> Output Class Initialized
DEBUG - 2011-09-16 19:18:33 --> Security Class Initialized
DEBUG - 2011-09-16 19:18:33 --> Input Class Initialized
DEBUG - 2011-09-16 19:18:33 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:18:33 --> Language Class Initialized
DEBUG - 2011-09-16 19:18:33 --> Loader Class Initialized
DEBUG - 2011-09-16 19:18:33 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:18:33 --> Controller Class Initialized
ERROR - 2011-09-16 19:18:33 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Entities/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:33 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:33 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 19:18:46 --> Config Class Initialized
DEBUG - 2011-09-16 19:18:46 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:18:46 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:18:46 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:18:46 --> URI Class Initialized
DEBUG - 2011-09-16 19:18:46 --> Router Class Initialized
DEBUG - 2011-09-16 19:18:46 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:18:46 --> Output Class Initialized
DEBUG - 2011-09-16 19:18:46 --> Security Class Initialized
DEBUG - 2011-09-16 19:18:46 --> Input Class Initialized
DEBUG - 2011-09-16 19:18:46 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:18:46 --> Language Class Initialized
DEBUG - 2011-09-16 19:18:46 --> Loader Class Initialized
DEBUG - 2011-09-16 19:18:46 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:18:46 --> Controller Class Initialized
ERROR - 2011-09-16 19:18:46 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Repositories/UserRepository does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:46 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:18:46 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 19:19:14 --> Config Class Initialized
DEBUG - 2011-09-16 19:19:14 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:19:14 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:19:14 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:19:14 --> URI Class Initialized
DEBUG - 2011-09-16 19:19:14 --> Router Class Initialized
DEBUG - 2011-09-16 19:19:14 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:19:14 --> Output Class Initialized
DEBUG - 2011-09-16 19:19:14 --> Security Class Initialized
DEBUG - 2011-09-16 19:19:14 --> Input Class Initialized
DEBUG - 2011-09-16 19:19:14 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:19:14 --> Language Class Initialized
DEBUG - 2011-09-16 19:19:14 --> Loader Class Initialized
DEBUG - 2011-09-16 19:19:14 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:19:14 --> Controller Class Initialized
ERROR - 2011-09-16 19:19:14 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class Entities/User does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:19:14 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:19:14 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 19:19:30 --> Config Class Initialized
DEBUG - 2011-09-16 19:19:30 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:19:30 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:19:30 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:19:30 --> URI Class Initialized
DEBUG - 2011-09-16 19:19:30 --> Router Class Initialized
DEBUG - 2011-09-16 19:19:30 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:19:30 --> Output Class Initialized
DEBUG - 2011-09-16 19:19:30 --> Security Class Initialized
DEBUG - 2011-09-16 19:19:30 --> Input Class Initialized
DEBUG - 2011-09-16 19:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:19:30 --> Language Class Initialized
DEBUG - 2011-09-16 19:19:30 --> Loader Class Initialized
DEBUG - 2011-09-16 19:19:30 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:19:30 --> Controller Class Initialized
ERROR - 2011-09-16 19:19:30 --> Severity: Warning  --> class_parents() [<a href='function.class-parents'>function.class-parents</a>]: Class models/Entities/User does not exist and could not be loaded D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:19:30 --> Severity: Warning  --> array_reverse() expects parameter 1 to be array, boolean given D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
ERROR - 2011-09-16 19:19:31 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\dev\web\vcib\application\libraries\Doctrine\ORM\Mapping\ClassMetadataFactory.php 222
DEBUG - 2011-09-16 19:19:39 --> Config Class Initialized
DEBUG - 2011-09-16 19:19:39 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:19:39 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:19:39 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:19:39 --> URI Class Initialized
DEBUG - 2011-09-16 19:19:39 --> Router Class Initialized
DEBUG - 2011-09-16 19:19:39 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:19:39 --> Output Class Initialized
DEBUG - 2011-09-16 19:19:39 --> Security Class Initialized
DEBUG - 2011-09-16 19:19:39 --> Input Class Initialized
DEBUG - 2011-09-16 19:19:39 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:19:39 --> Language Class Initialized
DEBUG - 2011-09-16 19:19:39 --> Loader Class Initialized
DEBUG - 2011-09-16 19:19:39 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:19:39 --> Controller Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Config Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Hooks Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Utf8 Class Initialized
DEBUG - 2011-09-16 19:20:11 --> UTF-8 Support Enabled
DEBUG - 2011-09-16 19:20:11 --> URI Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Router Class Initialized
DEBUG - 2011-09-16 19:20:11 --> No URI present. Default controller set.
DEBUG - 2011-09-16 19:20:11 --> Output Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Security Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Input Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-16 19:20:11 --> Language Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Loader Class Initialized
DEBUG - 2011-09-16 19:20:11 --> Helper loaded: url_helper
DEBUG - 2011-09-16 19:20:11 --> Controller Class Initialized
