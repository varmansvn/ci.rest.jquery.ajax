<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2012-02-15 17:35:13 --> Config Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Hooks Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Utf8 Class Initialized
DEBUG - 2012-02-15 17:35:13 --> UTF-8 Support Enabled
DEBUG - 2012-02-15 17:35:13 --> URI Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Router Class Initialized
DEBUG - 2012-02-15 17:35:13 --> No URI present. Default controller set.
DEBUG - 2012-02-15 17:35:13 --> Output Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Security Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Input Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-15 17:35:13 --> Language Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Loader Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Helper loaded: url_helper
DEBUG - 2012-02-15 17:35:13 --> Unit Testing Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Session Class Initialized
DEBUG - 2012-02-15 17:35:13 --> Helper loaded: string_helper
DEBUG - 2012-02-15 17:35:13 --> A session cookie was not found.
DEBUG - 2012-02-15 17:35:13 --> Session routines successfully run
DEBUG - 2012-02-15 17:35:13 --> Controller Class Initialized
DEBUG - 2012-02-15 17:35:13 --> File loaded: application/views/header.php
DEBUG - 2012-02-15 17:35:13 --> File loaded: application/views/nav.php
DEBUG - 2012-02-15 17:35:13 --> File loaded: application/views/login.php
DEBUG - 2012-02-15 17:35:13 --> File loaded: application/views/home.php
DEBUG - 2012-02-15 17:35:13 --> File loaded: application/views/footer.php
DEBUG - 2012-02-15 17:35:13 --> File loaded: application/views/layout.php
DEBUG - 2012-02-15 17:35:13 --> Final output sent to browser
DEBUG - 2012-02-15 17:35:13 --> Total execution time: 0.2413
DEBUG - 2012-02-15 17:35:36 --> Config Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Hooks Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Utf8 Class Initialized
DEBUG - 2012-02-15 17:35:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-15 17:35:36 --> URI Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Router Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Output Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Security Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Input Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-15 17:35:36 --> Language Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Loader Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Helper loaded: url_helper
DEBUG - 2012-02-15 17:35:36 --> Unit Testing Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Session Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Helper loaded: string_helper
DEBUG - 2012-02-15 17:35:36 --> Session routines successfully run
DEBUG - 2012-02-15 17:35:36 --> Controller Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Config file loaded: application/config/rest.php
DEBUG - 2012-02-15 17:35:36 --> Helper loaded: inflector_helper
DEBUG - 2012-02-15 17:35:36 --> Config Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Hooks Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Utf8 Class Initialized
DEBUG - 2012-02-15 17:35:36 --> UTF-8 Support Enabled
DEBUG - 2012-02-15 17:35:36 --> URI Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Router Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Output Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Security Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Input Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-15 17:35:36 --> Language Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Loader Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Helper loaded: url_helper
DEBUG - 2012-02-15 17:35:36 --> Unit Testing Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Session Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Helper loaded: string_helper
DEBUG - 2012-02-15 17:35:36 --> Session routines successfully run
DEBUG - 2012-02-15 17:35:36 --> Controller Class Initialized
DEBUG - 2012-02-15 17:35:36 --> Config file loaded: application/config/rest.php
DEBUG - 2012-02-15 17:35:36 --> Helper loaded: inflector_helper
INFO  - 2012-02-15 17:35:36 --> Users::login_post::20function entry
INFO  - 2012-02-15 17:35:36 --> UserBusiness::validateUser::36,function entry
INFO  - 2012-02-15 17:35:36 --> Repositories\UserRepository::findUserByEmail::34,function entry
DEBUG - 2012-02-15 17:38:43 --> Config Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Hooks Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Utf8 Class Initialized
DEBUG - 2012-02-15 17:38:43 --> UTF-8 Support Enabled
DEBUG - 2012-02-15 17:38:43 --> URI Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Router Class Initialized
DEBUG - 2012-02-15 17:38:43 --> No URI present. Default controller set.
DEBUG - 2012-02-15 17:38:43 --> Output Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Security Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Input Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-15 17:38:43 --> Language Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Loader Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Helper loaded: url_helper
DEBUG - 2012-02-15 17:38:43 --> Unit Testing Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Session Class Initialized
DEBUG - 2012-02-15 17:38:43 --> Helper loaded: string_helper
DEBUG - 2012-02-15 17:38:43 --> Session routines successfully run
DEBUG - 2012-02-15 17:38:43 --> Controller Class Initialized
DEBUG - 2012-02-15 17:38:43 --> File loaded: application/views/header.php
DEBUG - 2012-02-15 17:38:43 --> File loaded: application/views/nav.php
DEBUG - 2012-02-15 17:38:43 --> File loaded: application/views/login.php
DEBUG - 2012-02-15 17:38:43 --> File loaded: application/views/home.php
DEBUG - 2012-02-15 17:38:43 --> File loaded: application/views/footer.php
DEBUG - 2012-02-15 17:38:43 --> File loaded: application/views/layout.php
DEBUG - 2012-02-15 17:38:43 --> Final output sent to browser
DEBUG - 2012-02-15 17:38:43 --> Total execution time: 0.2995
DEBUG - 2012-02-15 17:38:46 --> Config Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Hooks Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Utf8 Class Initialized
DEBUG - 2012-02-15 17:38:46 --> UTF-8 Support Enabled
DEBUG - 2012-02-15 17:38:46 --> URI Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Router Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Output Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Security Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Input Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-15 17:38:46 --> Language Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Loader Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Helper loaded: url_helper
DEBUG - 2012-02-15 17:38:46 --> Unit Testing Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Session Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Helper loaded: string_helper
DEBUG - 2012-02-15 17:38:46 --> Session routines successfully run
DEBUG - 2012-02-15 17:38:46 --> Controller Class Initialized
DEBUG - 2012-02-15 17:38:46 --> Config file loaded: application/config/rest.php
DEBUG - 2012-02-15 17:38:46 --> Helper loaded: inflector_helper
INFO  - 2012-02-15 17:38:46 --> Users::login_post::20function entry
INFO  - 2012-02-15 17:38:46 --> UserBusiness::validateUser::36,function entry
INFO  - 2012-02-15 17:38:46 --> Repositories\UserRepository::findUserByEmail::34,function entry
DEBUG - 2012-02-15 17:39:17 --> Config Class Initialized
DEBUG - 2012-02-15 17:39:17 --> Hooks Class Initialized
DEBUG - 2012-02-15 17:39:17 --> Utf8 Class Initialized
DEBUG - 2012-02-15 17:39:17 --> UTF-8 Support Enabled
DEBUG - 2012-02-15 17:39:18 --> URI Class Initialized
DEBUG - 2012-02-15 17:39:18 --> Router Class Initialized
DEBUG - 2012-02-15 17:39:18 --> No URI present. Default controller set.
DEBUG - 2012-02-15 17:39:18 --> Output Class Initialized
DEBUG - 2012-02-15 17:39:18 --> Security Class Initialized
DEBUG - 2012-02-15 17:39:18 --> Input Class Initialized
DEBUG - 2012-02-15 17:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-15 17:39:18 --> Language Class Initialized
DEBUG - 2012-02-15 17:39:18 --> Loader Class Initialized
DEBUG - 2012-02-15 17:39:18 --> Helper loaded: url_helper
DEBUG - 2012-02-15 17:39:18 --> Unit Testing Class Initialized
DEBUG - 2012-02-15 17:39:18 --> Session Class Initialized
DEBUG - 2012-02-15 17:39:18 --> Helper loaded: string_helper
DEBUG - 2012-02-15 17:39:18 --> Session routines successfully run
DEBUG - 2012-02-15 17:39:18 --> Controller Class Initialized
DEBUG - 2012-02-15 17:39:18 --> File loaded: application/views/header.php
DEBUG - 2012-02-15 17:39:18 --> File loaded: application/views/nav.php
DEBUG - 2012-02-15 17:39:18 --> File loaded: application/views/login.php
DEBUG - 2012-02-15 17:39:18 --> File loaded: application/views/home.php
DEBUG - 2012-02-15 17:39:18 --> File loaded: application/views/footer.php
DEBUG - 2012-02-15 17:39:18 --> File loaded: application/views/layout.php
DEBUG - 2012-02-15 17:39:18 --> Final output sent to browser
DEBUG - 2012-02-15 17:39:18 --> Total execution time: 0.2801
DEBUG - 2012-02-15 17:39:19 --> Config Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Hooks Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Utf8 Class Initialized
DEBUG - 2012-02-15 17:39:19 --> UTF-8 Support Enabled
DEBUG - 2012-02-15 17:39:19 --> URI Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Router Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Output Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Security Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Input Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-15 17:39:19 --> Language Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Loader Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Helper loaded: url_helper
DEBUG - 2012-02-15 17:39:19 --> Unit Testing Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Session Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Helper loaded: string_helper
DEBUG - 2012-02-15 17:39:19 --> Session routines successfully run
DEBUG - 2012-02-15 17:39:19 --> Controller Class Initialized
DEBUG - 2012-02-15 17:39:19 --> Config file loaded: application/config/rest.php
DEBUG - 2012-02-15 17:39:19 --> Helper loaded: inflector_helper
INFO  - 2012-02-15 17:39:19 --> Users::login_post::20function entry
INFO  - 2012-02-15 17:39:19 --> UserBusiness::validateUser::36,function entry
INFO  - 2012-02-15 17:39:19 --> Repositories\UserRepository::findUserByEmail::34,function entry
DEBUG - 2012-02-15 17:40:34 --> Config Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Hooks Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Utf8 Class Initialized
DEBUG - 2012-02-15 17:40:34 --> UTF-8 Support Enabled
DEBUG - 2012-02-15 17:40:34 --> URI Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Router Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Output Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Security Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Input Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Global POST and COOKIE data sanitized
DEBUG - 2012-02-15 17:40:34 --> Language Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Loader Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Helper loaded: url_helper
DEBUG - 2012-02-15 17:40:34 --> Unit Testing Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Session Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Helper loaded: string_helper
DEBUG - 2012-02-15 17:40:34 --> Session routines successfully run
DEBUG - 2012-02-15 17:40:34 --> Controller Class Initialized
DEBUG - 2012-02-15 17:40:34 --> Config file loaded: application/config/rest.php
DEBUG - 2012-02-15 17:40:34 --> Helper loaded: inflector_helper
INFO  - 2012-02-15 17:40:34 --> Users::login_post::20function entry
INFO  - 2012-02-15 17:40:34 --> UserBusiness::validateUser::36,function entry
INFO  - 2012-02-15 17:40:34 --> Repositories\UserRepository::findUserByEmail::34,function entry
INFO  - 2012-02-15 17:40:34 --> Repositories\UserRepository::findUserByEmail::64,functione exit
INFO  - 2012-02-15 17:40:34 --> Repositories\UserSecurityRepository::findSaltByUser::14,function entry
INFO  - 2012-02-15 17:40:34 --> Repositories\UserSecurityRepository::findSaltByUser::40,functione exit
INFO  - 2012-02-15 17:40:34 --> UserBusiness::validateUser::79,functione exit
