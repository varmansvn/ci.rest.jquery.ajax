<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2011-09-15 11:02:54 --> Config Class Initialized
DEBUG - 2011-09-15 11:02:54 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:02:54 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:02:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:02:54 --> URI Class Initialized
DEBUG - 2011-09-15 11:02:54 --> Router Class Initialized
DEBUG - 2011-09-15 11:02:54 --> No URI present. Default controller set.
DEBUG - 2011-09-15 11:02:54 --> Output Class Initialized
DEBUG - 2011-09-15 11:02:54 --> Security Class Initialized
DEBUG - 2011-09-15 11:02:54 --> Input Class Initialized
DEBUG - 2011-09-15 11:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:02:54 --> Language Class Initialized
DEBUG - 2011-09-15 11:02:54 --> Loader Class Initialized
DEBUG - 2011-09-15 11:02:54 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:02:54 --> Controller Class Initialized
DEBUG - 2011-09-15 11:02:54 --> File loaded: application/views/header.php
DEBUG - 2011-09-15 11:02:54 --> File loaded: application/views/nav.php
DEBUG - 2011-09-15 11:02:54 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-15 11:02:54 --> File loaded: application/views/footer.php
DEBUG - 2011-09-15 11:02:54 --> File loaded: application/views/layout.php
DEBUG - 2011-09-15 11:02:54 --> Final output sent to browser
DEBUG - 2011-09-15 11:02:54 --> Total execution time: 0.3212
DEBUG - 2011-09-15 11:02:56 --> Config Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:02:56 --> URI Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Router Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Output Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Security Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Input Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:02:56 --> Language Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Loader Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:02:56 --> Controller Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Config file loaded: application/config/rest.php
DEBUG - 2011-09-15 11:02:56 --> Helper loaded: inflector_helper
DEBUG - 2011-09-15 11:02:56 --> Config Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:02:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:02:56 --> URI Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Router Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Output Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Security Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Input Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:02:56 --> Language Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Loader Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:02:56 --> Controller Class Initialized
DEBUG - 2011-09-15 11:02:56 --> Config file loaded: application/config/rest.php
DEBUG - 2011-09-15 11:02:56 --> Helper loaded: inflector_helper
DEBUG - 2011-09-15 11:02:57 --> Config Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:02:57 --> URI Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Router Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Output Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Security Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Input Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:02:57 --> Language Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Loader Class Initialized
DEBUG - 2011-09-15 11:02:57 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:02:57 --> Controller Class Initialized
DEBUG - 2011-09-15 11:02:57 --> File loaded: application/views/header.php
DEBUG - 2011-09-15 11:02:57 --> File loaded: application/views/nav.php
DEBUG - 2011-09-15 11:02:57 --> File loaded: application/views/new_user.php
DEBUG - 2011-09-15 11:02:57 --> File loaded: application/views/footer.php
DEBUG - 2011-09-15 11:02:57 --> File loaded: application/views/layout.php
DEBUG - 2011-09-15 11:02:57 --> Final output sent to browser
DEBUG - 2011-09-15 11:02:57 --> Total execution time: 0.1344
DEBUG - 2011-09-15 11:03:01 --> Config Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:03:01 --> URI Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Router Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Output Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Security Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Input Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:03:01 --> Language Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Loader Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:03:01 --> Controller Class Initialized
DEBUG - 2011-09-15 11:03:01 --> Config file loaded: application/config/rest.php
DEBUG - 2011-09-15 11:03:01 --> Helper loaded: inflector_helper
DEBUG - 2011-09-15 11:03:52 --> Config Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:03:52 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:03:52 --> URI Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Router Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Output Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Security Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Input Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:03:52 --> Language Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Loader Class Initialized
DEBUG - 2011-09-15 11:03:52 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:03:52 --> Controller Class Initialized
DEBUG - 2011-09-15 11:03:52 --> File loaded: application/views/header.php
DEBUG - 2011-09-15 11:03:52 --> File loaded: application/views/nav.php
DEBUG - 2011-09-15 11:03:52 --> File loaded: application/views/new_user.php
DEBUG - 2011-09-15 11:03:52 --> File loaded: application/views/footer.php
DEBUG - 2011-09-15 11:03:52 --> File loaded: application/views/layout.php
DEBUG - 2011-09-15 11:03:52 --> Final output sent to browser
DEBUG - 2011-09-15 11:03:52 --> Total execution time: 0.0936
DEBUG - 2011-09-15 11:03:54 --> Config Class Initialized
DEBUG - 2011-09-15 11:03:54 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:03:54 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:03:54 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:03:54 --> URI Class Initialized
DEBUG - 2011-09-15 11:03:54 --> Router Class Initialized
DEBUG - 2011-09-15 11:03:54 --> No URI present. Default controller set.
DEBUG - 2011-09-15 11:03:54 --> Output Class Initialized
DEBUG - 2011-09-15 11:03:54 --> Security Class Initialized
DEBUG - 2011-09-15 11:03:54 --> Input Class Initialized
DEBUG - 2011-09-15 11:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:03:54 --> Language Class Initialized
DEBUG - 2011-09-15 11:03:54 --> Loader Class Initialized
DEBUG - 2011-09-15 11:03:54 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:03:54 --> Controller Class Initialized
DEBUG - 2011-09-15 11:03:54 --> File loaded: application/views/header.php
DEBUG - 2011-09-15 11:03:54 --> File loaded: application/views/nav.php
DEBUG - 2011-09-15 11:03:54 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-15 11:03:54 --> File loaded: application/views/footer.php
DEBUG - 2011-09-15 11:03:54 --> File loaded: application/views/layout.php
DEBUG - 2011-09-15 11:03:54 --> Final output sent to browser
DEBUG - 2011-09-15 11:03:54 --> Total execution time: 0.2088
DEBUG - 2011-09-15 11:03:55 --> Config Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:03:55 --> URI Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Router Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Output Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Security Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Input Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:03:55 --> Language Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Loader Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:03:55 --> Controller Class Initialized
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/header.php
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/nav.php
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/all_users.php
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/footer.php
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/layout.php
DEBUG - 2011-09-15 11:03:55 --> Final output sent to browser
DEBUG - 2011-09-15 11:03:55 --> Total execution time: 0.0880
DEBUG - 2011-09-15 11:03:55 --> Config Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:03:55 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:03:55 --> URI Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Router Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Output Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Security Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Input Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:03:55 --> Language Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Loader Class Initialized
DEBUG - 2011-09-15 11:03:55 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:03:55 --> Controller Class Initialized
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/header.php
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/nav.php
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/new_user.php
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/footer.php
DEBUG - 2011-09-15 11:03:55 --> File loaded: application/views/layout.php
DEBUG - 2011-09-15 11:03:56 --> Final output sent to browser
DEBUG - 2011-09-15 11:03:56 --> Total execution time: 0.2206
DEBUG - 2011-09-15 11:03:56 --> Config Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:03:56 --> URI Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Router Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Output Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Security Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Input Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:03:56 --> Language Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Loader Class Initialized
DEBUG - 2011-09-15 11:03:56 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:03:56 --> Controller Class Initialized
DEBUG - 2011-09-15 11:03:56 --> File loaded: application/views/header.php
DEBUG - 2011-09-15 11:03:56 --> File loaded: application/views/nav.php
DEBUG - 2011-09-15 11:03:56 --> File loaded: application/views/update_user.php
DEBUG - 2011-09-15 11:03:56 --> File loaded: application/views/footer.php
DEBUG - 2011-09-15 11:03:56 --> File loaded: application/views/layout.php
DEBUG - 2011-09-15 11:03:56 --> Final output sent to browser
DEBUG - 2011-09-15 11:03:56 --> Total execution time: 0.1780
DEBUG - 2011-09-15 11:03:57 --> Config Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:03:57 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:03:57 --> URI Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Router Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Output Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Security Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Input Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:03:57 --> Language Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Loader Class Initialized
DEBUG - 2011-09-15 11:03:57 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:03:57 --> Controller Class Initialized
DEBUG - 2011-09-15 11:03:57 --> File loaded: application/views/header.php
DEBUG - 2011-09-15 11:03:57 --> File loaded: application/views/nav.php
DEBUG - 2011-09-15 11:03:57 --> File loaded: application/views/delete_user.php
DEBUG - 2011-09-15 11:03:57 --> File loaded: application/views/footer.php
DEBUG - 2011-09-15 11:03:57 --> File loaded: application/views/layout.php
DEBUG - 2011-09-15 11:03:57 --> Final output sent to browser
DEBUG - 2011-09-15 11:03:57 --> Total execution time: 0.1095
DEBUG - 2011-09-15 11:04:00 --> Config Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Hooks Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Utf8 Class Initialized
DEBUG - 2011-09-15 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2011-09-15 11:04:00 --> URI Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Router Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Output Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Security Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Input Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2011-09-15 11:04:00 --> Language Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Loader Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Helper loaded: url_helper
DEBUG - 2011-09-15 11:04:00 --> Controller Class Initialized
DEBUG - 2011-09-15 11:04:00 --> Config file loaded: application/config/rest.php
DEBUG - 2011-09-15 11:04:00 --> Helper loaded: inflector_helper
DEBUG - 2011-09-15 11:04:00 --> XSS Filtering completed
