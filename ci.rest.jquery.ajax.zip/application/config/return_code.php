<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$start = 100;
define('STATUS_SUCCESS', $start++);
define('ERROR_INVALID_PRODUCT_REPO', $start++);
define('ERROR_INVALID_ENTITY_MANAGER', $start++);
define('ERROR_CREATE_QUERY', $start++);
define('ERROR_INVALID_USERLIST', $start++);
define('ERROR_INVALID_USER_REPO', $start++);
