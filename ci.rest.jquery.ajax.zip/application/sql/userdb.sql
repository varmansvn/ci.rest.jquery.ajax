create table user(
id int not null auto_increment,
name char(32) not null, 
primary key(id));